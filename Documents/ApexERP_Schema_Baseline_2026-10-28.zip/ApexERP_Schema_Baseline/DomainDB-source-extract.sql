USE [master]
GO
/****** Object:  Database [DomainDB]    Script Date: 10/28/2026 8:08:18 AM ******/
CREATE DATABASE [DomainDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'DomainDB', FILENAME = N'C:\Users\UT011647\DomainDB.mdf' , SIZE = 73728KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'DomainDB_log', FILENAME = N'C:\Users\UT011647\DomainDB_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [DomainDB].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [DomainDB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [DomainDB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [DomainDB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [DomainDB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [DomainDB] SET ARITHABORT OFF 
GO
ALTER DATABASE [DomainDB] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [DomainDB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [DomainDB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [DomainDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [DomainDB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [DomainDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [DomainDB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [DomainDB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [DomainDB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [DomainDB] SET  ENABLE_BROKER 
GO
ALTER DATABASE [DomainDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [DomainDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [DomainDB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [DomainDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [DomainDB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [DomainDB] SET READ_COMMITTED_SNAPSHOT ON 
GO
ALTER DATABASE [DomainDB] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [DomainDB] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [DomainDB] SET  MULTI_USER 
GO
ALTER DATABASE [DomainDB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [DomainDB] SET DB_CHAINING OFF 
GO
ALTER DATABASE [DomainDB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [DomainDB] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [DomainDB] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [DomainDB] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [DomainDB] SET QUERY_STORE = ON
GO
ALTER DATABASE [DomainDB] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [DomainDB]
GO
/****** Object:  Table [dbo].[__EFMigrationsHistory]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[__EFMigrationsHistory](
	[MigrationId] [nvarchar](150) NOT NULL,
	[ProductVersion] [nvarchar](32) NOT NULL,
 CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY CLUSTERED 
(
	[MigrationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Addresses]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Addresses](
	[AddressId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[AddressName] [nvarchar](100) NOT NULL,
	[AddressLine1] [nvarchar](250) NOT NULL,
	[AddressLine2] [nvarchar](250) NULL,
	[City] [nvarchar](100) NOT NULL,
	[StateProvince] [nvarchar](100) NULL,
	[PostalCode] [nvarchar](20) NULL,
	[CountryId] [uniqueidentifier] NULL,
	[UnmatchedCountryText] [nvarchar](100) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Addresses] PRIMARY KEY CLUSTERED 
(
	[AddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_Addresses_TenantId_AddressId] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[AddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AddressTypes]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AddressTypes](
	[AddressTypeId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NULL,
	[Code] [nvarchar](50) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](250) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_AddressTypes] PRIMARY KEY CLUSTERED 
(
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ApprovalAuditRecords]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ApprovalAuditRecords](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[DocumentType] [nvarchar](50) NOT NULL,
	[DocumentId] [uniqueidentifier] NOT NULL,
	[ActorUserId] [uniqueidentifier] NOT NULL,
	[ActorUserName] [nvarchar](150) NOT NULL,
	[Decision] [int] NOT NULL,
	[IsAutomated] [bit] NOT NULL,
	[DecisionDateUtc] [datetime2](7) NOT NULL,
	[Remarks] [nvarchar](500) NULL,
	[SnapshotAmount] [decimal](18, 2) NULL,
 CONSTRAINT [PK_ApprovalAuditRecords] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BranchAddresses]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BranchAddresses](
	[BranchAddressId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[BranchId] [uniqueidentifier] NOT NULL,
	[AddressId] [uniqueidentifier] NOT NULL,
	[AddressTypeId] [uniqueidentifier] NOT NULL,
	[IsDefault] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_BranchAddresses] PRIMARY KEY CLUSTERED 
(
	[BranchAddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Branches]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Branches](
	[Id] [uniqueidentifier] NOT NULL,
	[CompanyId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
	[Code] [nvarchar](max) NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_Branches] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Brands]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Brands](
	[BrandId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[BrandCode] [nvarchar](50) NOT NULL,
	[BrandName] [nvarchar](150) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Brands] PRIMARY KEY CLUSTERED 
(
	[BrandId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Categories]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Categories](
	[CategoryId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CategoryCode] [nvarchar](50) NOT NULL,
	[CategoryName] [nvarchar](200) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Categories] PRIMARY KEY CLUSTERED 
(
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_Categories_TenantId_CategoryId] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Companies]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Companies](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](max) NOT NULL,
	[Code] [nvarchar](max) NOT NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_Companies] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_Companies_TenantId_Id] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CompanyAddresses]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CompanyAddresses](
	[CompanyAddressId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CompanyId] [uniqueidentifier] NOT NULL,
	[AddressId] [uniqueidentifier] NOT NULL,
	[AddressTypeId] [uniqueidentifier] NOT NULL,
	[IsDefault] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_CompanyAddresses] PRIMARY KEY CLUSTERED 
(
	[CompanyAddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Contacts]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Contacts](
	[ContactId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[ContactName] [nvarchar](200) NOT NULL,
	[JobTitle] [nvarchar](100) NULL,
	[Email] [nvarchar](200) NULL,
	[Phone] [nvarchar](50) NULL,
	[MobileNumber] [nvarchar](50) NULL,
	[PreferredContactMethod] [nvarchar](20) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Contacts] PRIMARY KEY CLUSTERED 
(
	[ContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_Contacts_TenantId_ContactId] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[ContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ContactTypes]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ContactTypes](
	[ContactTypeId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NULL,
	[Code] [nvarchar](50) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](250) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ContactTypes] PRIMARY KEY CLUSTERED 
(
	[ContactTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Countries]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Countries](
	[CountryId] [uniqueidentifier] NOT NULL,
	[Alpha2Code] [nchar](2) NOT NULL,
	[Alpha3Code] [nchar](3) NOT NULL,
	[NumericCode] [nvarchar](3) NULL,
	[CountryName] [nvarchar](100) NOT NULL,
	[OfficialName] [nvarchar](200) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Countries] PRIMARY KEY CLUSTERED 
(
	[CountryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Currencies]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Currencies](
	[CurrencyId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CurrencyCode] [nvarchar](3) NOT NULL,
	[CurrencyName] [nvarchar](100) NOT NULL,
	[Symbol] [nvarchar](10) NOT NULL,
	[DecimalPlaces] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Currencies] PRIMARY KEY CLUSTERED 
(
	[CurrencyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CustomerAddresses]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CustomerAddresses](
	[CustomerAddressId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[AddressId] [uniqueidentifier] NOT NULL,
	[AddressTypeId] [uniqueidentifier] NOT NULL,
	[IsDefault] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_CustomerAddresses] PRIMARY KEY CLUSTERED 
(
	[CustomerAddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CustomerContacts]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CustomerContacts](
	[CustomerContactId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[ContactId] [uniqueidentifier] NOT NULL,
	[ContactTypeId] [uniqueidentifier] NOT NULL,
	[IsPrimary] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_CustomerContacts] PRIMARY KEY CLUSTERED 
(
	[CustomerContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Customers]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Customers](
	[CustomerId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CustomerCode] [nvarchar](50) NOT NULL,
	[CustomerName] [nvarchar](200) NOT NULL,
	[ContactPerson] [nvarchar](200) NULL,
	[Email] [nvarchar](200) NULL,
	[Phone] [nvarchar](50) NULL,
	[AddressLine1] [nvarchar](250) NULL,
	[AddressLine2] [nvarchar](250) NULL,
	[City] [nvarchar](100) NULL,
	[PostalCode] [nvarchar](20) NULL,
	[Country] [nvarchar](100) NULL,
	[TaxNumber] [nvarchar](100) NULL,
	[CreditLimit] [decimal](18, 2) NOT NULL,
	[PaymentTerms] [nvarchar](100) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED 
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_Customers_TenantId_CustomerId] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DomainAuditRecords]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DomainAuditRecords](
	[AuditId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NULL,
	[EntityName] [nvarchar](200) NOT NULL,
	[EntityId] [nvarchar](100) NOT NULL,
	[Action] [nvarchar](50) NOT NULL,
	[UserId] [uniqueidentifier] NULL,
	[Timestamp] [datetime2](7) NOT NULL,
	[OldValues] [nvarchar](max) NULL,
	[NewValues] [nvarchar](max) NULL,
 CONSTRAINT [PK_DomainAuditRecords] PRIMARY KEY CLUSTERED 
(
	[AuditId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[GoodsReceiptNoteLines]    Script Date: 10/28/2026 8:08:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GoodsReceiptNoteLines](
	[GoodsReceiptNoteLineId] [uniqueidentifier] NOT NULL,
	[GoodsReceiptNoteId] [uniqueidentifier] NOT NULL,
	[PurchaseOrderItemId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[WarehouseLocationId] [uniqueidentifier] NOT NULL,
	[QuantityReceived] [decimal](18, 4) NOT NULL,
	[UnitCost] [decimal](18, 2) NOT NULL,
	[LineTotal] [decimal](18, 2) NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[BatchNumber] [nvarchar](100) NULL,
	[SerialNumber] [nvarchar](100) NULL,
	[ExpiryDate] [datetime2](7) NULL,
	[IsQuarantine] [bit] NOT NULL,
	[Remarks] [nvarchar](500) NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[ManufacturingDate] [datetime2](7) NULL,
 CONSTRAINT [PK_GoodsReceiptNoteLines] PRIMARY KEY CLUSTERED 
(
	[GoodsReceiptNoteLineId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[GoodsReceiptNotes]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GoodsReceiptNotes](
	[GoodsReceiptNoteId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CompanyId] [uniqueidentifier] NOT NULL,
	[BranchId] [uniqueidentifier] NOT NULL,
	[PurchaseOrderId] [uniqueidentifier] NOT NULL,
	[SupplierId] [uniqueidentifier] NULL,
	[GrnNumber] [nvarchar](50) NOT NULL,
	[ReceiptDate] [datetime2](7) NOT NULL,
	[Status] [int] NOT NULL,
	[DeliveryNoteNumber] [nvarchar](100) NULL,
	[Remarks] [nvarchar](500) NULL,
	[TotalAmount] [decimal](18, 2) NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_GoodsReceiptNotes] PRIMARY KEY CLUSTERED 
(
	[GoodsReceiptNoteId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[InventoryBalances]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InventoryBalances](
	[InventoryBalanceId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[WarehouseLocationId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[BatchNumber] [nvarchar](100) NOT NULL,
	[SerialNumber] [nvarchar](100) NOT NULL,
	[QuantityOnHand] [decimal](18, 4) NOT NULL,
	[QuantityAllocated] [decimal](18, 4) NOT NULL,
	[QuantityQuarantine] [decimal](18, 4) NOT NULL,
	[QuantityOnOrder] [decimal](18, 4) NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_InventoryBalances] PRIMARY KEY CLUSTERED 
(
	[InventoryBalanceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[InventoryCostLayers]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InventoryCostLayers](
	[CostLayerId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[WarehouseLocationId] [uniqueidentifier] NOT NULL,
	[InventoryTransactionId] [uniqueidentifier] NOT NULL,
	[LayerDate] [datetime2](7) NOT NULL,
	[OriginalQuantity] [decimal](18, 4) NOT NULL,
	[RemainingQuantity] [decimal](18, 4) NOT NULL,
	[UnitCost] [decimal](18, 4) NOT NULL,
	[OriginalCost] [decimal](18, 2) NOT NULL,
	[RemainingCost] [decimal](18, 2) NOT NULL,
	[BatchNumber] [nvarchar](100) NOT NULL,
	[SerialNumber] [nvarchar](100) NOT NULL,
	[IsExhausted] [bit] NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_InventoryCostLayers] PRIMARY KEY CLUSTERED 
(
	[CostLayerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[InventoryTransactions]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InventoryTransactions](
	[InventoryTransactionId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[TransactionNumber] [nvarchar](50) NOT NULL,
	[MovementType] [int] NOT NULL,
	[SourceDocumentType] [int] NOT NULL,
	[SourceDocumentId] [uniqueidentifier] NOT NULL,
	[SourceDocumentLineId] [uniqueidentifier] NOT NULL,
	[MovementSequence] [int] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[WarehouseLocationId] [uniqueidentifier] NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[Quantity] [decimal](18, 4) NOT NULL,
	[UnitCost] [decimal](18, 4) NOT NULL,
	[TotalCost] [decimal](18, 2) NOT NULL,
	[BatchNumber] [nvarchar](100) NULL,
	[SerialNumber] [nvarchar](100) NULL,
	[ExpiryDate] [datetime2](7) NULL,
	[TransactionDate] [datetime2](7) NOT NULL,
	[ReversalOfTransactionId] [uniqueidentifier] NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_InventoryTransactions] PRIMARY KEY CLUSTERED 
(
	[InventoryTransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[LocationTypes]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LocationTypes](
	[LocationTypeId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NULL,
	[Code] [nvarchar](50) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](250) NULL,
	[CanStoreInventory] [bit] NOT NULL,
	[CanPick] [bit] NOT NULL,
	[CanPutAway] [bit] NOT NULL,
	[CanContainChildren] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_LocationTypes] PRIMARY KEY CLUSTERED 
(
	[LocationTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PaymentTerms]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PaymentTerms](
	[PaymentTermId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[TermCode] [nvarchar](50) NOT NULL,
	[TermName] [nvarchar](150) NOT NULL,
	[Days] [int] NOT NULL,
	[Description] [nvarchar](500) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_PaymentTerms] PRIMARY KEY CLUSTERED 
(
	[PaymentTermId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProductBatches]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductBatches](
	[ProductBatchId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[BatchNumber] [nvarchar](100) NOT NULL,
	[ManufacturingDate] [datetime2](7) NULL,
	[ExpiryDate] [datetime2](7) NULL,
	[IsActive] [bit] NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ProductBatches] PRIMARY KEY CLUSTERED 
(
	[ProductBatchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Products]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Products](
	[ProductId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[ProductCode] [nvarchar](50) NOT NULL,
	[ProductName] [nvarchar](200) NOT NULL,
	[CategoryId] [uniqueidentifier] NOT NULL,
	[Description] [nvarchar](500) NULL,
	[UnitOfMeasure] [nvarchar](50) NOT NULL,
	[IsManufacturable] [bit] NOT NULL,
	[IsPurchasable] [bit] NOT NULL,
	[IsSellable] [bit] NOT NULL,
	[ValuationMethod] [int] NOT NULL,
	[StandardCost] [decimal](18, 2) NOT NULL,
	[SellingPrice] [decimal](18, 2) NOT NULL,
	[ReorderLevel] [decimal](18, 2) NOT NULL,
	[ReorderQuantity] [decimal](18, 2) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[CanConsumeInMaintenance] [bit] NOT NULL,
	[CanConsumeInProduction] [bit] NOT NULL,
	[IsStockTracked] [bit] NOT NULL,
	[ProductType] [int] NOT NULL,
	[TrackingMode] [int] NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[LeadTimeDays] [int] NULL,
	[MaxStockQuantity] [decimal](18, 2) NULL,
	[MinStockQuantity] [decimal](18, 2) NULL,
	[SafetyStockQuantity] [decimal](18, 2) NULL,
 CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED 
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_Products_TenantId_ProductId] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProductValuationBalances]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductValuationBalances](
	[ProductValuationBalanceId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[TotalQuantity] [decimal](18, 4) NOT NULL,
	[TotalCostValue] [decimal](18, 2) NOT NULL,
	[CurrentAverageCost] [decimal](18, 4) NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ProductValuationBalances] PRIMARY KEY CLUSTERED 
(
	[ProductValuationBalanceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProductWarehouseSettings]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductWarehouseSettings](
	[ProductWarehouseSettingId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[ReorderLevel] [decimal](18, 2) NULL,
	[ReorderQuantity] [decimal](18, 2) NULL,
	[MinStockQuantity] [decimal](18, 2) NULL,
	[MaxStockQuantity] [decimal](18, 2) NULL,
	[SafetyStockQuantity] [decimal](18, 2) NULL,
	[LeadTimeDays] [int] NULL,
	[IsActive] [bit] NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ProductWarehouseSettings] PRIMARY KEY CLUSTERED 
(
	[ProductWarehouseSettingId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PurchaseOrderItems]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PurchaseOrderItems](
	[Id] [uniqueidentifier] NOT NULL,
	[PurchaseOrderId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[Quantity] [decimal](18, 4) NOT NULL,
	[UnitPrice] [decimal](18, 2) NOT NULL,
	[LineTotal] [decimal](18, 2) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[ReceivedQuantity] [decimal](18, 4) NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[DiscountAmount] [decimal](18, 2) NOT NULL,
	[DiscountRate] [decimal](18, 2) NOT NULL,
	[IsTaxInclusive] [bit] NOT NULL,
	[Notes] [nvarchar](500) NULL,
	[SubTotal] [decimal](18, 2) NOT NULL,
	[TaxAmount] [decimal](18, 2) NOT NULL,
	[TaxCodeId] [uniqueidentifier] NULL,
	[TaxRate] [decimal](18, 4) NOT NULL,
 CONSTRAINT [PK_PurchaseOrderItems] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PurchaseOrders]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PurchaseOrders](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CompanyId] [uniqueidentifier] NOT NULL,
	[BranchId] [uniqueidentifier] NOT NULL,
	[OrderNumber] [nvarchar](50) NOT NULL,
	[OrderDate] [datetime2](7) NOT NULL,
	[Status] [int] NOT NULL,
	[TotalAmount] [decimal](18, 2) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedByUserId] [uniqueidentifier] NULL,
	[SupplierId] [uniqueidentifier] NULL,
	[Currency] [nvarchar](10) NOT NULL,
	[DiscountAmount] [decimal](18, 2) NOT NULL,
	[SubTotal] [decimal](18, 2) NOT NULL,
	[TaxAmount] [decimal](18, 2) NOT NULL,
 CONSTRAINT [PK_PurchaseOrders] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PurchaseRequisitionItems]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PurchaseRequisitionItems](
	[Id] [uniqueidentifier] NOT NULL,
	[PurchaseRequisitionId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[Quantity] [decimal](18, 4) NOT NULL,
	[EstimatedUnitPrice] [decimal](18, 2) NOT NULL,
	[EstimatedLineTotal] [decimal](18, 2) NOT NULL,
	[Remarks] [nvarchar](250) NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_PurchaseRequisitionItems] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PurchaseRequisitions]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PurchaseRequisitions](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CompanyId] [uniqueidentifier] NOT NULL,
	[BranchId] [uniqueidentifier] NOT NULL,
	[RequisitionNumber] [nvarchar](50) NOT NULL,
	[RequisitionDate] [datetime2](7) NOT NULL,
	[RequiredDate] [datetime2](7) NULL,
	[RequestorUserId] [uniqueidentifier] NOT NULL,
	[Status] [int] NOT NULL,
	[TotalAmount] [decimal](18, 2) NOT NULL,
	[Notes] [nvarchar](500) NULL,
	[IsActive] [bit] NOT NULL,
 CONSTRAINT [PK_PurchaseRequisitions] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PutawayLineAllocations]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PutawayLineAllocations](
	[PutawayLineAllocationId] [uniqueidentifier] NOT NULL,
	[PutawayLineId] [uniqueidentifier] NOT NULL,
	[DestinationWarehouseLocationId] [uniqueidentifier] NOT NULL,
	[AllocatedQuantity] [decimal](18, 4) NOT NULL,
	[MovementSequence] [int] NOT NULL,
	[InventoryTransactionId] [uniqueidentifier] NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_PutawayLineAllocations] PRIMARY KEY CLUSTERED 
(
	[PutawayLineAllocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PutawayLines]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PutawayLines](
	[PutawayLineId] [uniqueidentifier] NOT NULL,
	[PutawayId] [uniqueidentifier] NOT NULL,
	[SourceDocumentLineId] [uniqueidentifier] NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[SourceWarehouseLocationId] [uniqueidentifier] NOT NULL,
	[ReceivedQuantity] [decimal](18, 4) NOT NULL,
	[PreviouslyPutawayQuantity] [decimal](18, 4) NOT NULL,
	[OutstandingQuantity] [decimal](18, 4) NOT NULL,
	[PutawayQuantity] [decimal](18, 4) NOT NULL,
	[BatchNumber] [nvarchar](100) NULL,
	[SerialNumber] [nvarchar](100) NULL,
	[ExpiryDate] [datetime2](7) NULL,
	[Notes] [nvarchar](500) NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_PutawayLines] PRIMARY KEY CLUSTERED 
(
	[PutawayLineId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Putaways]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Putaways](
	[PutawayId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CompanyId] [uniqueidentifier] NOT NULL,
	[BranchId] [uniqueidentifier] NOT NULL,
	[PutawayNumber] [nvarchar](50) NOT NULL,
	[PutawayDate] [datetime2](7) NOT NULL,
	[SourceDocumentType] [int] NOT NULL,
	[SourceDocumentId] [uniqueidentifier] NOT NULL,
	[SourceDocumentNumber] [nvarchar](100) NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[Status] [int] NOT NULL,
	[Notes] [nvarchar](500) NULL,
	[RowVersion] [timestamp] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Putaways] PRIMARY KEY CLUSTERED 
(
	[PutawayId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SalesInvoiceItems]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SalesInvoiceItems](
	[Id] [uniqueidentifier] NOT NULL,
	[SalesInvoiceId] [uniqueidentifier] NOT NULL,
	[SalesOrderItemId] [uniqueidentifier] NULL,
	[SalesShipmentItemId] [uniqueidentifier] NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[Quantity] [decimal](18, 4) NOT NULL,
	[UnitPrice] [decimal](18, 4) NOT NULL,
	[DiscountRate] [decimal](5, 2) NOT NULL,
	[DiscountAmount] [decimal](18, 4) NOT NULL,
	[TaxRate] [decimal](18, 4) NOT NULL,
	[TaxAmount] [decimal](18, 4) NOT NULL,
	[Subtotal] [decimal](18, 4) NOT NULL,
	[LineTotal] [decimal](18, 4) NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[Notes] [nvarchar](500) NULL,
	[IsActive] [bit] NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[IsTaxInclusive] [bit] NOT NULL,
	[TaxCodeId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SalesInvoiceItems] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SalesInvoices]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SalesInvoices](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CompanyId] [uniqueidentifier] NOT NULL,
	[BranchId] [uniqueidentifier] NOT NULL,
	[SalesOrderId] [uniqueidentifier] NOT NULL,
	[SalesShipmentId] [uniqueidentifier] NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[InvoiceNumber] [nvarchar](50) NOT NULL,
	[InvoiceDate] [datetime2](7) NOT NULL,
	[DueDate] [datetime2](7) NULL,
	[Status] [int] NOT NULL,
	[Currency] [nvarchar](10) NOT NULL,
	[PaymentTerms] [nvarchar](100) NULL,
	[Subtotal] [decimal](18, 4) NOT NULL,
	[DiscountAmount] [decimal](18, 4) NOT NULL,
	[TaxAmount] [decimal](18, 4) NOT NULL,
	[TotalAmount] [decimal](18, 4) NOT NULL,
	[Notes] [nvarchar](1000) NULL,
	[ConfirmedAt] [datetime2](7) NULL,
	[ConfirmedBy] [uniqueidentifier] NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SalesInvoices] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SalesOrderItems]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SalesOrderItems](
	[Id] [uniqueidentifier] NOT NULL,
	[SalesOrderId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[Quantity] [decimal](18, 4) NOT NULL,
	[UnitPrice] [decimal](18, 2) NOT NULL,
	[DiscountRate] [decimal](18, 2) NOT NULL,
	[DiscountAmount] [decimal](18, 2) NOT NULL,
	[TaxRate] [decimal](18, 4) NOT NULL,
	[TaxAmount] [decimal](18, 2) NOT NULL,
	[SubTotal] [decimal](18, 2) NOT NULL,
	[LineTotal] [decimal](18, 2) NOT NULL,
	[Notes] [nvarchar](500) NULL,
	[IsActive] [bit] NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[IsTaxInclusive] [bit] NOT NULL,
	[TaxCodeId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SalesOrderItems] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SalesOrders]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SalesOrders](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CompanyId] [uniqueidentifier] NOT NULL,
	[BranchId] [uniqueidentifier] NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[CreatedByUserId] [uniqueidentifier] NULL,
	[OrderNumber] [nvarchar](50) NOT NULL,
	[DocumentType] [int] NOT NULL,
	[OrderDate] [datetime2](7) NOT NULL,
	[DeliveryDate] [datetime2](7) NULL,
	[Currency] [nvarchar](10) NOT NULL,
	[PaymentTerms] [nvarchar](100) NULL,
	[Status] [int] NOT NULL,
	[SubTotal] [decimal](18, 2) NOT NULL,
	[DiscountAmount] [decimal](18, 2) NOT NULL,
	[TaxAmount] [decimal](18, 2) NOT NULL,
	[TotalAmount] [decimal](18, 2) NOT NULL,
	[Notes] [nvarchar](1000) NULL,
	[OpportunityId] [uniqueidentifier] NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[DeliveryAddressId] [uniqueidentifier] NULL,
	[DeliveryAddressSnapshot] [nvarchar](500) NULL,
 CONSTRAINT [PK_SalesOrders] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SalesShipmentItems]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SalesShipmentItems](
	[Id] [uniqueidentifier] NOT NULL,
	[SalesShipmentId] [uniqueidentifier] NOT NULL,
	[SalesOrderItemId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[WarehouseLocationId] [uniqueidentifier] NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[QuantityDispatched] [decimal](18, 4) NOT NULL,
	[BatchNumber] [nvarchar](100) NULL,
	[SerialNumber] [nvarchar](100) NULL,
	[Notes] [nvarchar](500) NULL,
	[IsActive] [bit] NOT NULL,
	[RowVersion] [timestamp] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SalesShipmentItems] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SalesShipments]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SalesShipments](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CompanyId] [uniqueidentifier] NOT NULL,
	[BranchId] [uniqueidentifier] NOT NULL,
	[SalesOrderId] [uniqueidentifier] NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NULL,
	[ShipmentNumber] [nvarchar](50) NOT NULL,
	[Status] [int] NOT NULL,
	[Method] [int] NOT NULL,
	[ShipmentDate] [datetime2](7) NOT NULL,
	[DispatchedAt] [datetime2](7) NULL,
	[DeliveredAt] [datetime2](7) NULL,
	[CarrierName] [nvarchar](100) NULL,
	[TrackingNumber] [nvarchar](100) NULL,
	[RecipientName] [nvarchar](100) NULL,
	[DeliveryAddress] [nvarchar](500) NULL,
	[VehicleNumber] [nvarchar](50) NULL,
	[Notes] [nvarchar](1000) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[InvoiceId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SalesShipments] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SupplierAddresses]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SupplierAddresses](
	[SupplierAddressId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[SupplierId] [uniqueidentifier] NOT NULL,
	[AddressId] [uniqueidentifier] NOT NULL,
	[AddressTypeId] [uniqueidentifier] NOT NULL,
	[IsDefault] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SupplierAddresses] PRIMARY KEY CLUSTERED 
(
	[SupplierAddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SupplierContacts]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SupplierContacts](
	[SupplierContactId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[SupplierId] [uniqueidentifier] NOT NULL,
	[ContactId] [uniqueidentifier] NOT NULL,
	[ContactTypeId] [uniqueidentifier] NOT NULL,
	[IsPrimary] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SupplierContacts] PRIMARY KEY CLUSTERED 
(
	[SupplierContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SupplierProductPrices]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SupplierProductPrices](
	[SupplierProductPriceId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[SupplierId] [uniqueidentifier] NOT NULL,
	[ProductId] [uniqueidentifier] NOT NULL,
	[SupplierItemCode] [nvarchar](50) NULL,
	[UnitPrice] [decimal](18, 4) NOT NULL,
	[Currency] [nchar](3) NOT NULL,
	[UnitOfMeasureId] [uniqueidentifier] NULL,
	[MinimumOrderQuantity] [decimal](18, 4) NOT NULL,
	[EffectiveFrom] [datetime2](7) NOT NULL,
	[EffectiveTo] [datetime2](7) NULL,
	[LeadTimeDays] [int] NULL,
	[IsPreferred] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SupplierProductPrices] PRIMARY KEY CLUSTERED 
(
	[SupplierProductPriceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Suppliers]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Suppliers](
	[SupplierId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[SupplierCode] [nvarchar](50) NOT NULL,
	[SupplierName] [nvarchar](200) NOT NULL,
	[ContactPerson] [nvarchar](200) NULL,
	[Email] [nvarchar](200) NULL,
	[Phone] [nvarchar](50) NULL,
	[AddressLine1] [nvarchar](250) NULL,
	[AddressLine2] [nvarchar](250) NULL,
	[City] [nvarchar](100) NULL,
	[PostalCode] [nvarchar](20) NULL,
	[Country] [nvarchar](100) NULL,
	[TaxNumber] [nvarchar](100) NULL,
	[CreditTerms] [nvarchar](100) NULL,
	[PaymentTerms] [nvarchar](100) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Suppliers] PRIMARY KEY CLUSTERED 
(
	[SupplierId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_Suppliers_TenantId_SupplierId] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[SupplierId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TaxCodes]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TaxCodes](
	[TaxCodeId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[Code] [nvarchar](50) NOT NULL,
	[Name] [nvarchar](150) NOT NULL,
	[Rate] [decimal](18, 4) NOT NULL,
	[Applicability] [int] NOT NULL,
	[EffectiveFrom] [datetime2](7) NULL,
	[EffectiveTo] [datetime2](7) NULL,
	[Description] [nvarchar](500) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_TaxCodes] PRIMARY KEY CLUSTERED 
(
	[TaxCodeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UnitOfMeasureConversions]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UnitOfMeasureConversions](
	[ConversionId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[FromUnitId] [uniqueidentifier] NOT NULL,
	[ToUnitId] [uniqueidentifier] NOT NULL,
	[ConversionFactor] [decimal](18, 6) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_UnitOfMeasureConversions] PRIMARY KEY CLUSTERED 
(
	[ConversionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UnitsOfMeasure]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UnitsOfMeasure](
	[UnitOfMeasureId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[Code] [nvarchar](50) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](250) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_UnitsOfMeasure] PRIMARY KEY CLUSTERED 
(
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_UnitsOfMeasure_TenantId_UnitOfMeasureId] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[WarehouseAddresses]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[WarehouseAddresses](
	[WarehouseAddressId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[AddressId] [uniqueidentifier] NOT NULL,
	[AddressTypeId] [uniqueidentifier] NOT NULL,
	[IsDefault] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_WarehouseAddresses] PRIMARY KEY CLUSTERED 
(
	[WarehouseAddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[WarehouseLocations]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[WarehouseLocations](
	[WarehouseLocationId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[WarehouseZoneId] [uniqueidentifier] NULL,
	[LocationCode] [nvarchar](50) NOT NULL,
	[LocationName] [nvarchar](200) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[LocationTypeId] [uniqueidentifier] NULL,
	[ParentLocationId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_WarehouseLocations] PRIMARY KEY CLUSTERED 
(
	[WarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_WarehouseLocations_TenantId_WarehouseId_WarehouseLocationId] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[WarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Warehouses]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Warehouses](
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[WarehouseCode] [nvarchar](50) NOT NULL,
	[WarehouseName] [nvarchar](200) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[AddressLine1] [nvarchar](250) NULL,
	[AddressLine2] [nvarchar](250) NULL,
	[City] [nvarchar](100) NULL,
	[PostalCode] [nvarchar](20) NULL,
	[Country] [nvarchar](100) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[BranchId] [uniqueidentifier] NULL,
	[CompanyId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Warehouses] PRIMARY KEY CLUSTERED 
(
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [AK_Warehouses_TenantId_WarehouseId] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[WarehouseZones]    Script Date: 10/28/2026 8:08:19 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[WarehouseZones](
	[WarehouseZoneId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[WarehouseId] [uniqueidentifier] NOT NULL,
	[ZoneCode] [nvarchar](50) NOT NULL,
	[ZoneName] [nvarchar](200) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_WarehouseZones] PRIMARY KEY CLUSTERED 
(
	[WarehouseZoneId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Index [IX_Addresses_CountryId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_Addresses_CountryId] ON [dbo].[Addresses]
(
	[CountryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Addresses_TenantId_AddressId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Addresses_TenantId_AddressId] ON [dbo].[Addresses]
(
	[TenantId] ASC,
	[AddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_AddressTypes_TenantId_Code]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_AddressTypes_TenantId_Code] ON [dbo].[AddressTypes]
(
	[TenantId] ASC,
	[Code] ASC
)
WHERE ([TenantId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_ApprovalAuditRecords_TenantId_DocumentType_DocumentId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_ApprovalAuditRecords_TenantId_DocumentType_DocumentId] ON [dbo].[ApprovalAuditRecords]
(
	[TenantId] ASC,
	[DocumentType] ASC,
	[DocumentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_BranchAddresses_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_BranchAddresses_AddressTypeId] ON [dbo].[BranchAddresses]
(
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_BranchAddresses_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_BranchAddresses_BranchId] ON [dbo].[BranchAddresses]
(
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_BranchAddresses_TenantId_AddressId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_BranchAddresses_TenantId_AddressId] ON [dbo].[BranchAddresses]
(
	[TenantId] ASC,
	[AddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_BranchAddresses_TenantId_BranchId_AddressId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_BranchAddresses_TenantId_BranchId_AddressId_AddressTypeId] ON [dbo].[BranchAddresses]
(
	[TenantId] ASC,
	[BranchId] ASC,
	[AddressId] ASC,
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_BranchAddresses_TenantId_BranchId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_BranchAddresses_TenantId_BranchId_AddressTypeId] ON [dbo].[BranchAddresses]
(
	[TenantId] ASC,
	[BranchId] ASC,
	[AddressTypeId] ASC
)
WHERE ([IsDefault]=(1) AND [IsActive]=(1))
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Brands_TenantId_BrandCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Brands_TenantId_BrandCode] ON [dbo].[Brands]
(
	[TenantId] ASC,
	[BrandCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Brands_TenantId_BrandId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Brands_TenantId_BrandId] ON [dbo].[Brands]
(
	[TenantId] ASC,
	[BrandId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Categories_TenantId_CategoryCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Categories_TenantId_CategoryCode] ON [dbo].[Categories]
(
	[TenantId] ASC,
	[CategoryCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Categories_TenantId_CategoryId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Categories_TenantId_CategoryId] ON [dbo].[Categories]
(
	[TenantId] ASC,
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Categories_TenantId_CategoryName]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Categories_TenantId_CategoryName] ON [dbo].[Categories]
(
	[TenantId] ASC,
	[CategoryName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Companies_TenantId_Id]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Companies_TenantId_Id] ON [dbo].[Companies]
(
	[TenantId] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CompanyAddresses_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_CompanyAddresses_AddressTypeId] ON [dbo].[CompanyAddresses]
(
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CompanyAddresses_TenantId_AddressId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_CompanyAddresses_TenantId_AddressId] ON [dbo].[CompanyAddresses]
(
	[TenantId] ASC,
	[AddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CompanyAddresses_TenantId_CompanyId_AddressId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_CompanyAddresses_TenantId_CompanyId_AddressId_AddressTypeId] ON [dbo].[CompanyAddresses]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[AddressId] ASC,
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CompanyAddresses_TenantId_CompanyId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_CompanyAddresses_TenantId_CompanyId_AddressTypeId] ON [dbo].[CompanyAddresses]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[AddressTypeId] ASC
)
WHERE ([IsDefault]=(1) AND [IsActive]=(1))
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Contacts_TenantId_ContactId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Contacts_TenantId_ContactId] ON [dbo].[Contacts]
(
	[TenantId] ASC,
	[ContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_ContactTypes_TenantId_Code]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_ContactTypes_TenantId_Code] ON [dbo].[ContactTypes]
(
	[TenantId] ASC,
	[Code] ASC
)
WHERE ([TenantId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Countries_Alpha2Code]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Countries_Alpha2Code] ON [dbo].[Countries]
(
	[Alpha2Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Countries_Alpha3Code]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Countries_Alpha3Code] ON [dbo].[Countries]
(
	[Alpha3Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Countries_CountryName]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Countries_CountryName] ON [dbo].[Countries]
(
	[CountryName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Currencies_TenantId_CurrencyCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Currencies_TenantId_CurrencyCode] ON [dbo].[Currencies]
(
	[TenantId] ASC,
	[CurrencyCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Currencies_TenantId_CurrencyId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Currencies_TenantId_CurrencyId] ON [dbo].[Currencies]
(
	[TenantId] ASC,
	[CurrencyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CustomerAddresses_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_CustomerAddresses_AddressTypeId] ON [dbo].[CustomerAddresses]
(
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CustomerAddresses_TenantId_AddressId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_CustomerAddresses_TenantId_AddressId] ON [dbo].[CustomerAddresses]
(
	[TenantId] ASC,
	[AddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CustomerAddresses_TenantId_CustomerId_AddressId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_CustomerAddresses_TenantId_CustomerId_AddressId_AddressTypeId] ON [dbo].[CustomerAddresses]
(
	[TenantId] ASC,
	[CustomerId] ASC,
	[AddressId] ASC,
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CustomerAddresses_TenantId_CustomerId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_CustomerAddresses_TenantId_CustomerId_AddressTypeId] ON [dbo].[CustomerAddresses]
(
	[TenantId] ASC,
	[CustomerId] ASC,
	[AddressTypeId] ASC
)
WHERE ([IsDefault]=(1) AND [IsActive]=(1))
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CustomerContacts_ContactTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_CustomerContacts_ContactTypeId] ON [dbo].[CustomerContacts]
(
	[ContactTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CustomerContacts_TenantId_ContactId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_CustomerContacts_TenantId_ContactId] ON [dbo].[CustomerContacts]
(
	[TenantId] ASC,
	[ContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CustomerContacts_TenantId_CustomerId_ContactId_ContactTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_CustomerContacts_TenantId_CustomerId_ContactId_ContactTypeId] ON [dbo].[CustomerContacts]
(
	[TenantId] ASC,
	[CustomerId] ASC,
	[ContactId] ASC,
	[ContactTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CustomerContacts_TenantId_CustomerId_ContactTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_CustomerContacts_TenantId_CustomerId_ContactTypeId] ON [dbo].[CustomerContacts]
(
	[TenantId] ASC,
	[CustomerId] ASC,
	[ContactTypeId] ASC
)
WHERE ([IsPrimary]=(1) AND [IsActive]=(1))
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Customers_TenantId_CustomerCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Customers_TenantId_CustomerCode] ON [dbo].[Customers]
(
	[TenantId] ASC,
	[CustomerCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Customers_TenantId_CustomerId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Customers_TenantId_CustomerId] ON [dbo].[Customers]
(
	[TenantId] ASC,
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_DomainAuditRecords_TenantId_EntityName_EntityId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_DomainAuditRecords_TenantId_EntityName_EntityId] ON [dbo].[DomainAuditRecords]
(
	[TenantId] ASC,
	[EntityName] ASC,
	[EntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_DomainAuditRecords_Timestamp]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_DomainAuditRecords_Timestamp] ON [dbo].[DomainAuditRecords]
(
	[Timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_GoodsReceiptNoteLines_GoodsReceiptNoteId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_GoodsReceiptNoteLines_GoodsReceiptNoteId] ON [dbo].[GoodsReceiptNoteLines]
(
	[GoodsReceiptNoteId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_GoodsReceiptNoteLines_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_GoodsReceiptNoteLines_ProductId] ON [dbo].[GoodsReceiptNoteLines]
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_GoodsReceiptNoteLines_PurchaseOrderItemId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_GoodsReceiptNoteLines_PurchaseOrderItemId] ON [dbo].[GoodsReceiptNoteLines]
(
	[PurchaseOrderItemId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_GoodsReceiptNoteLines_WarehouseId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_GoodsReceiptNoteLines_WarehouseId] ON [dbo].[GoodsReceiptNoteLines]
(
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_GoodsReceiptNoteLines_WarehouseLocationId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_GoodsReceiptNoteLines_WarehouseLocationId] ON [dbo].[GoodsReceiptNoteLines]
(
	[WarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_GoodsReceiptNotes_PurchaseOrderId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_GoodsReceiptNotes_PurchaseOrderId] ON [dbo].[GoodsReceiptNotes]
(
	[PurchaseOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_GoodsReceiptNotes_TenantId_CompanyId_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_GoodsReceiptNotes_TenantId_CompanyId_BranchId] ON [dbo].[GoodsReceiptNotes]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_GoodsReceiptNotes_TenantId_CompanyId_GrnNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_GoodsReceiptNotes_TenantId_CompanyId_GrnNumber] ON [dbo].[GoodsReceiptNotes]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[GrnNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_GoodsReceiptNotes_TenantId_PurchaseOrderId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_GoodsReceiptNotes_TenantId_PurchaseOrderId] ON [dbo].[GoodsReceiptNotes]
(
	[TenantId] ASC,
	[PurchaseOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryBalances_TenantId_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryBalances_TenantId_ProductId] ON [dbo].[InventoryBalances]
(
	[TenantId] ASC,
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryBalances_TenantId_WarehouseId_WarehouseLocationId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryBalances_TenantId_WarehouseId_WarehouseLocationId] ON [dbo].[InventoryBalances]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[WarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_InventoryBalances_TenantId_WarehouseLocationId_ProductId_BatchNumber_SerialNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_InventoryBalances_TenantId_WarehouseLocationId_ProductId_BatchNumber_SerialNumber] ON [dbo].[InventoryBalances]
(
	[TenantId] ASC,
	[WarehouseLocationId] ASC,
	[ProductId] ASC,
	[BatchNumber] ASC,
	[SerialNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryCostLayers_InventoryTransactionId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryCostLayers_InventoryTransactionId] ON [dbo].[InventoryCostLayers]
(
	[InventoryTransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryCostLayers_TenantId_InventoryTransactionId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryCostLayers_TenantId_InventoryTransactionId] ON [dbo].[InventoryCostLayers]
(
	[TenantId] ASC,
	[InventoryTransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryCostLayers_TenantId_ProductId_WarehouseId_IsExhausted_LayerDate_CostLayerId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryCostLayers_TenantId_ProductId_WarehouseId_IsExhausted_LayerDate_CostLayerId] ON [dbo].[InventoryCostLayers]
(
	[TenantId] ASC,
	[ProductId] ASC,
	[WarehouseId] ASC,
	[IsExhausted] ASC,
	[LayerDate] ASC,
	[CostLayerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryCostLayers_TenantId_WarehouseId_WarehouseLocationId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryCostLayers_TenantId_WarehouseId_WarehouseLocationId] ON [dbo].[InventoryCostLayers]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[WarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryTransactions_ReversalOfTransactionId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryTransactions_ReversalOfTransactionId] ON [dbo].[InventoryTransactions]
(
	[ReversalOfTransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryTransactions_TenantId_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryTransactions_TenantId_ProductId] ON [dbo].[InventoryTransactions]
(
	[TenantId] ASC,
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryTransactions_TenantId_SourceDocumentType_SourceDocumentId_SourceDocumentLineId_MovementType_MovementSequence]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_InventoryTransactions_TenantId_SourceDocumentType_SourceDocumentId_SourceDocumentLineId_MovementType_MovementSequence] ON [dbo].[InventoryTransactions]
(
	[TenantId] ASC,
	[SourceDocumentType] ASC,
	[SourceDocumentId] ASC,
	[SourceDocumentLineId] ASC,
	[MovementType] ASC,
	[MovementSequence] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_InventoryTransactions_TenantId_TransactionNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_InventoryTransactions_TenantId_TransactionNumber] ON [dbo].[InventoryTransactions]
(
	[TenantId] ASC,
	[TransactionNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryTransactions_TenantId_WarehouseId_WarehouseLocationId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryTransactions_TenantId_WarehouseId_WarehouseLocationId] ON [dbo].[InventoryTransactions]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[WarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_LocationTypes_TenantId_Code]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_LocationTypes_TenantId_Code] ON [dbo].[LocationTypes]
(
	[TenantId] ASC,
	[Code] ASC
)
WHERE ([TenantId] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PaymentTerms_TenantId_PaymentTermId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_PaymentTerms_TenantId_PaymentTermId] ON [dbo].[PaymentTerms]
(
	[TenantId] ASC,
	[PaymentTermId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_PaymentTerms_TenantId_TermCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_PaymentTerms_TenantId_TermCode] ON [dbo].[PaymentTerms]
(
	[TenantId] ASC,
	[TermCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_ProductBatches_TenantId_BatchNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_ProductBatches_TenantId_BatchNumber] ON [dbo].[ProductBatches]
(
	[TenantId] ASC,
	[BatchNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_ProductBatches_TenantId_ProductId_BatchNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_ProductBatches_TenantId_ProductId_BatchNumber] ON [dbo].[ProductBatches]
(
	[TenantId] ASC,
	[ProductId] ASC,
	[BatchNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Products_TenantId_CategoryId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_Products_TenantId_CategoryId] ON [dbo].[Products]
(
	[TenantId] ASC,
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Products_TenantId_ProductCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Products_TenantId_ProductCode] ON [dbo].[Products]
(
	[TenantId] ASC,
	[ProductCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Products_TenantId_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Products_TenantId_ProductId] ON [dbo].[Products]
(
	[TenantId] ASC,
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Products_TenantId_ProductName]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Products_TenantId_ProductName] ON [dbo].[Products]
(
	[TenantId] ASC,
	[ProductName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Products_TenantId_UnitOfMeasureId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_Products_TenantId_UnitOfMeasureId] ON [dbo].[Products]
(
	[TenantId] ASC,
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductValuationBalances_TenantId_ProductId_WarehouseId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_ProductValuationBalances_TenantId_ProductId_WarehouseId] ON [dbo].[ProductValuationBalances]
(
	[TenantId] ASC,
	[ProductId] ASC,
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductValuationBalances_TenantId_WarehouseId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_ProductValuationBalances_TenantId_WarehouseId] ON [dbo].[ProductValuationBalances]
(
	[TenantId] ASC,
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductWarehouseSettings_TenantId_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_ProductWarehouseSettings_TenantId_ProductId] ON [dbo].[ProductWarehouseSettings]
(
	[TenantId] ASC,
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductWarehouseSettings_TenantId_ProductId_WarehouseId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_ProductWarehouseSettings_TenantId_ProductId_WarehouseId] ON [dbo].[ProductWarehouseSettings]
(
	[TenantId] ASC,
	[ProductId] ASC,
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductWarehouseSettings_TenantId_WarehouseId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_ProductWarehouseSettings_TenantId_WarehouseId] ON [dbo].[ProductWarehouseSettings]
(
	[TenantId] ASC,
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseOrderItems_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseOrderItems_ProductId] ON [dbo].[PurchaseOrderItems]
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseOrderItems_PurchaseOrderId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseOrderItems_PurchaseOrderId] ON [dbo].[PurchaseOrderItems]
(
	[PurchaseOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseOrderItems_UnitOfMeasureId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseOrderItems_UnitOfMeasureId] ON [dbo].[PurchaseOrderItems]
(
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseOrders_SupplierId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseOrders_SupplierId] ON [dbo].[PurchaseOrders]
(
	[SupplierId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseOrders_TenantId_CompanyId_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseOrders_TenantId_CompanyId_BranchId] ON [dbo].[PurchaseOrders]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_PurchaseOrders_TenantId_CompanyId_OrderNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_PurchaseOrders_TenantId_CompanyId_OrderNumber] ON [dbo].[PurchaseOrders]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[OrderNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseOrders_TenantId_SupplierId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseOrders_TenantId_SupplierId] ON [dbo].[PurchaseOrders]
(
	[TenantId] ASC,
	[SupplierId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseRequisitionItems_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseRequisitionItems_ProductId] ON [dbo].[PurchaseRequisitionItems]
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseRequisitionItems_PurchaseRequisitionId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseRequisitionItems_PurchaseRequisitionId] ON [dbo].[PurchaseRequisitionItems]
(
	[PurchaseRequisitionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseRequisitionItems_UnitOfMeasureId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseRequisitionItems_UnitOfMeasureId] ON [dbo].[PurchaseRequisitionItems]
(
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PurchaseRequisitions_TenantId_CompanyId_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PurchaseRequisitions_TenantId_CompanyId_BranchId] ON [dbo].[PurchaseRequisitions]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_PurchaseRequisitions_TenantId_CompanyId_RequisitionNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_PurchaseRequisitions_TenantId_CompanyId_RequisitionNumber] ON [dbo].[PurchaseRequisitions]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[RequisitionNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PutawayLineAllocations_DestinationWarehouseLocationId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PutawayLineAllocations_DestinationWarehouseLocationId] ON [dbo].[PutawayLineAllocations]
(
	[DestinationWarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PutawayLineAllocations_InventoryTransactionId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PutawayLineAllocations_InventoryTransactionId] ON [dbo].[PutawayLineAllocations]
(
	[InventoryTransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PutawayLineAllocations_PutawayLineId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PutawayLineAllocations_PutawayLineId] ON [dbo].[PutawayLineAllocations]
(
	[PutawayLineId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PutawayLines_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PutawayLines_ProductId] ON [dbo].[PutawayLines]
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PutawayLines_PutawayId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PutawayLines_PutawayId] ON [dbo].[PutawayLines]
(
	[PutawayId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PutawayLines_SourceDocumentLineId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_PutawayLines_SourceDocumentLineId] ON [dbo].[PutawayLines]
(
	[SourceDocumentLineId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Putaways_TenantId_CompanyId_PutawayNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Putaways_TenantId_CompanyId_PutawayNumber] ON [dbo].[Putaways]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[PutawayNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Putaways_TenantId_SourceDocumentId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_Putaways_TenantId_SourceDocumentId] ON [dbo].[Putaways]
(
	[TenantId] ASC,
	[SourceDocumentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Putaways_TenantId_Status]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_Putaways_TenantId_Status] ON [dbo].[Putaways]
(
	[TenantId] ASC,
	[Status] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Putaways_TenantId_WarehouseId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_Putaways_TenantId_WarehouseId] ON [dbo].[Putaways]
(
	[TenantId] ASC,
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoiceItems_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoiceItems_ProductId] ON [dbo].[SalesInvoiceItems]
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoiceItems_SalesInvoiceId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoiceItems_SalesInvoiceId] ON [dbo].[SalesInvoiceItems]
(
	[SalesInvoiceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoiceItems_SalesOrderItemId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoiceItems_SalesOrderItemId] ON [dbo].[SalesInvoiceItems]
(
	[SalesOrderItemId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoiceItems_SalesShipmentItemId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoiceItems_SalesShipmentItemId] ON [dbo].[SalesInvoiceItems]
(
	[SalesShipmentItemId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoiceItems_UnitOfMeasureId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoiceItems_UnitOfMeasureId] ON [dbo].[SalesInvoiceItems]
(
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoices_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoices_BranchId] ON [dbo].[SalesInvoices]
(
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoices_CustomerId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoices_CustomerId] ON [dbo].[SalesInvoices]
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoices_SalesOrderId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoices_SalesOrderId] ON [dbo].[SalesInvoices]
(
	[SalesOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoices_SalesShipmentId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoices_SalesShipmentId] ON [dbo].[SalesInvoices]
(
	[SalesShipmentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoices_TenantId_CompanyId_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoices_TenantId_CompanyId_BranchId] ON [dbo].[SalesInvoices]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_SalesInvoices_TenantId_CompanyId_InvoiceNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SalesInvoices_TenantId_CompanyId_InvoiceNumber] ON [dbo].[SalesInvoices]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[InvoiceNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoices_TenantId_CustomerId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoices_TenantId_CustomerId] ON [dbo].[SalesInvoices]
(
	[TenantId] ASC,
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoices_TenantId_SalesOrderId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoices_TenantId_SalesOrderId] ON [dbo].[SalesInvoices]
(
	[TenantId] ASC,
	[SalesOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoices_TenantId_SalesShipmentId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoices_TenantId_SalesShipmentId] ON [dbo].[SalesInvoices]
(
	[TenantId] ASC,
	[SalesShipmentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesInvoices_TenantId_Status]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesInvoices_TenantId_Status] ON [dbo].[SalesInvoices]
(
	[TenantId] ASC,
	[Status] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesOrderItems_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesOrderItems_ProductId] ON [dbo].[SalesOrderItems]
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesOrderItems_SalesOrderId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesOrderItems_SalesOrderId] ON [dbo].[SalesOrderItems]
(
	[SalesOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesOrderItems_UnitOfMeasureId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesOrderItems_UnitOfMeasureId] ON [dbo].[SalesOrderItems]
(
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesOrders_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesOrders_BranchId] ON [dbo].[SalesOrders]
(
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesOrders_CustomerId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesOrders_CustomerId] ON [dbo].[SalesOrders]
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesOrders_TenantId_CompanyId_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesOrders_TenantId_CompanyId_BranchId] ON [dbo].[SalesOrders]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_SalesOrders_TenantId_CompanyId_OrderNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SalesOrders_TenantId_CompanyId_OrderNumber] ON [dbo].[SalesOrders]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[OrderNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesOrders_TenantId_CustomerId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesOrders_TenantId_CustomerId] ON [dbo].[SalesOrders]
(
	[TenantId] ASC,
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesOrders_TenantId_Status]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesOrders_TenantId_Status] ON [dbo].[SalesOrders]
(
	[TenantId] ASC,
	[Status] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipmentItems_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipmentItems_ProductId] ON [dbo].[SalesShipmentItems]
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipmentItems_SalesOrderItemId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipmentItems_SalesOrderItemId] ON [dbo].[SalesShipmentItems]
(
	[SalesOrderItemId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipmentItems_SalesShipmentId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipmentItems_SalesShipmentId] ON [dbo].[SalesShipmentItems]
(
	[SalesShipmentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipmentItems_UnitOfMeasureId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipmentItems_UnitOfMeasureId] ON [dbo].[SalesShipmentItems]
(
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipmentItems_WarehouseId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipmentItems_WarehouseId] ON [dbo].[SalesShipmentItems]
(
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipmentItems_WarehouseLocationId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipmentItems_WarehouseLocationId] ON [dbo].[SalesShipmentItems]
(
	[WarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipments_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipments_BranchId] ON [dbo].[SalesShipments]
(
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipments_CustomerId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipments_CustomerId] ON [dbo].[SalesShipments]
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipments_SalesOrderId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipments_SalesOrderId] ON [dbo].[SalesShipments]
(
	[SalesOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipments_TenantId_CompanyId_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipments_TenantId_CompanyId_BranchId] ON [dbo].[SalesShipments]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_SalesShipments_TenantId_CompanyId_ShipmentNumber]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SalesShipments_TenantId_CompanyId_ShipmentNumber] ON [dbo].[SalesShipments]
(
	[TenantId] ASC,
	[CompanyId] ASC,
	[ShipmentNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipments_TenantId_CustomerId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipments_TenantId_CustomerId] ON [dbo].[SalesShipments]
(
	[TenantId] ASC,
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipments_TenantId_SalesOrderId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipments_TenantId_SalesOrderId] ON [dbo].[SalesShipments]
(
	[TenantId] ASC,
	[SalesOrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SalesShipments_TenantId_Status]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SalesShipments_TenantId_Status] ON [dbo].[SalesShipments]
(
	[TenantId] ASC,
	[Status] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierAddresses_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SupplierAddresses_AddressTypeId] ON [dbo].[SupplierAddresses]
(
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierAddresses_TenantId_AddressId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SupplierAddresses_TenantId_AddressId] ON [dbo].[SupplierAddresses]
(
	[TenantId] ASC,
	[AddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierAddresses_TenantId_SupplierId_AddressId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SupplierAddresses_TenantId_SupplierId_AddressId_AddressTypeId] ON [dbo].[SupplierAddresses]
(
	[TenantId] ASC,
	[SupplierId] ASC,
	[AddressId] ASC,
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierAddresses_TenantId_SupplierId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SupplierAddresses_TenantId_SupplierId_AddressTypeId] ON [dbo].[SupplierAddresses]
(
	[TenantId] ASC,
	[SupplierId] ASC,
	[AddressTypeId] ASC
)
WHERE ([IsDefault]=(1) AND [IsActive]=(1))
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierContacts_ContactTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SupplierContacts_ContactTypeId] ON [dbo].[SupplierContacts]
(
	[ContactTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierContacts_TenantId_ContactId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SupplierContacts_TenantId_ContactId] ON [dbo].[SupplierContacts]
(
	[TenantId] ASC,
	[ContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierContacts_TenantId_SupplierId_ContactId_ContactTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SupplierContacts_TenantId_SupplierId_ContactId_ContactTypeId] ON [dbo].[SupplierContacts]
(
	[TenantId] ASC,
	[SupplierId] ASC,
	[ContactId] ASC,
	[ContactTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierContacts_TenantId_SupplierId_ContactTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SupplierContacts_TenantId_SupplierId_ContactTypeId] ON [dbo].[SupplierContacts]
(
	[TenantId] ASC,
	[SupplierId] ASC,
	[ContactTypeId] ASC
)
WHERE ([IsPrimary]=(1) AND [IsActive]=(1))
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierProductPrices_TenantId_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SupplierProductPrices_TenantId_ProductId] ON [dbo].[SupplierProductPrices]
(
	[TenantId] ASC,
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierProductPrices_TenantId_SupplierId_ProductId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SupplierProductPrices_TenantId_SupplierId_ProductId] ON [dbo].[SupplierProductPrices]
(
	[TenantId] ASC,
	[SupplierId] ASC,
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SupplierProductPrices_TenantId_UnitOfMeasureId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_SupplierProductPrices_TenantId_UnitOfMeasureId] ON [dbo].[SupplierProductPrices]
(
	[TenantId] ASC,
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Suppliers_TenantId_SupplierCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Suppliers_TenantId_SupplierCode] ON [dbo].[Suppliers]
(
	[TenantId] ASC,
	[SupplierCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Suppliers_TenantId_SupplierId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Suppliers_TenantId_SupplierId] ON [dbo].[Suppliers]
(
	[TenantId] ASC,
	[SupplierId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_TaxCodes_TenantId_Code]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_TaxCodes_TenantId_Code] ON [dbo].[TaxCodes]
(
	[TenantId] ASC,
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_TaxCodes_TenantId_TaxCodeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_TaxCodes_TenantId_TaxCodeId] ON [dbo].[TaxCodes]
(
	[TenantId] ASC,
	[TaxCodeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_UnitOfMeasureConversions_TenantId_FromUnitId_ToUnitId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_UnitOfMeasureConversions_TenantId_FromUnitId_ToUnitId] ON [dbo].[UnitOfMeasureConversions]
(
	[TenantId] ASC,
	[FromUnitId] ASC,
	[ToUnitId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_UnitOfMeasureConversions_TenantId_ToUnitId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_UnitOfMeasureConversions_TenantId_ToUnitId] ON [dbo].[UnitOfMeasureConversions]
(
	[TenantId] ASC,
	[ToUnitId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_UnitsOfMeasure_TenantId_Code]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_UnitsOfMeasure_TenantId_Code] ON [dbo].[UnitsOfMeasure]
(
	[TenantId] ASC,
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_UnitsOfMeasure_TenantId_UnitOfMeasureId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_UnitsOfMeasure_TenantId_UnitOfMeasureId] ON [dbo].[UnitsOfMeasure]
(
	[TenantId] ASC,
	[UnitOfMeasureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseAddresses_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_WarehouseAddresses_AddressTypeId] ON [dbo].[WarehouseAddresses]
(
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseAddresses_TenantId_AddressId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_WarehouseAddresses_TenantId_AddressId] ON [dbo].[WarehouseAddresses]
(
	[TenantId] ASC,
	[AddressId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseAddresses_TenantId_WarehouseId_AddressId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_WarehouseAddresses_TenantId_WarehouseId_AddressId_AddressTypeId] ON [dbo].[WarehouseAddresses]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[AddressId] ASC,
	[AddressTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseAddresses_TenantId_WarehouseId_AddressTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_WarehouseAddresses_TenantId_WarehouseId_AddressTypeId] ON [dbo].[WarehouseAddresses]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[AddressTypeId] ASC
)
WHERE ([IsDefault]=(1) AND [IsActive]=(1))
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseLocations_LocationTypeId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_WarehouseLocations_LocationTypeId] ON [dbo].[WarehouseLocations]
(
	[LocationTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_WarehouseLocations_TenantId_WarehouseId_LocationCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_WarehouseLocations_TenantId_WarehouseId_LocationCode] ON [dbo].[WarehouseLocations]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[LocationCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseLocations_TenantId_WarehouseId_ParentLocationId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_WarehouseLocations_TenantId_WarehouseId_ParentLocationId] ON [dbo].[WarehouseLocations]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[ParentLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseLocations_TenantId_WarehouseId_WarehouseLocationId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_WarehouseLocations_TenantId_WarehouseId_WarehouseLocationId] ON [dbo].[WarehouseLocations]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[WarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseLocations_TenantId_WarehouseLocationId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_WarehouseLocations_TenantId_WarehouseLocationId] ON [dbo].[WarehouseLocations]
(
	[TenantId] ASC,
	[WarehouseLocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseLocations_WarehouseZoneId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_WarehouseLocations_WarehouseZoneId] ON [dbo].[WarehouseLocations]
(
	[WarehouseZoneId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Warehouses_BranchId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_Warehouses_BranchId] ON [dbo].[Warehouses]
(
	[BranchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Warehouses_TenantId_CompanyId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE NONCLUSTERED INDEX [IX_Warehouses_TenantId_CompanyId] ON [dbo].[Warehouses]
(
	[TenantId] ASC,
	[CompanyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Warehouses_TenantId_WarehouseCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Warehouses_TenantId_WarehouseCode] ON [dbo].[Warehouses]
(
	[TenantId] ASC,
	[WarehouseCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Warehouses_TenantId_WarehouseId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Warehouses_TenantId_WarehouseId] ON [dbo].[Warehouses]
(
	[TenantId] ASC,
	[WarehouseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseZones_TenantId_WarehouseId_WarehouseZoneId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_WarehouseZones_TenantId_WarehouseId_WarehouseZoneId] ON [dbo].[WarehouseZones]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[WarehouseZoneId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_WarehouseZones_TenantId_WarehouseId_ZoneCode]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_WarehouseZones_TenantId_WarehouseId_ZoneCode] ON [dbo].[WarehouseZones]
(
	[TenantId] ASC,
	[WarehouseId] ASC,
	[ZoneCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_WarehouseZones_TenantId_WarehouseZoneId]    Script Date: 10/28/2026 8:08:19 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_WarehouseZones_TenantId_WarehouseZoneId] ON [dbo].[WarehouseZones]
(
	[TenantId] ASC,
	[WarehouseZoneId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Brands] ADD  DEFAULT (CONVERT([bit],(1))) FOR [IsActive]
GO
ALTER TABLE [dbo].[Currencies] ADD  DEFAULT ((2)) FOR [DecimalPlaces]
GO
ALTER TABLE [dbo].[Currencies] ADD  DEFAULT (CONVERT([bit],(1))) FOR [IsActive]
GO
ALTER TABLE [dbo].[PaymentTerms] ADD  DEFAULT ((0)) FOR [Days]
GO
ALTER TABLE [dbo].[PaymentTerms] ADD  DEFAULT (CONVERT([bit],(1))) FOR [IsActive]
GO
ALTER TABLE [dbo].[Products] ADD  DEFAULT (CONVERT([bit],(0))) FOR [CanConsumeInMaintenance]
GO
ALTER TABLE [dbo].[Products] ADD  DEFAULT (CONVERT([bit],(0))) FOR [CanConsumeInProduction]
GO
ALTER TABLE [dbo].[Products] ADD  DEFAULT (CONVERT([bit],(1))) FOR [IsStockTracked]
GO
ALTER TABLE [dbo].[Products] ADD  DEFAULT ((1)) FOR [ProductType]
GO
ALTER TABLE [dbo].[Products] ADD  DEFAULT ((0)) FOR [TrackingMode]
GO
ALTER TABLE [dbo].[PurchaseOrderItems] ADD  DEFAULT ((0.0)) FOR [ReceivedQuantity]
GO
ALTER TABLE [dbo].[PurchaseOrderItems] ADD  DEFAULT ((0.0)) FOR [DiscountAmount]
GO
ALTER TABLE [dbo].[PurchaseOrderItems] ADD  DEFAULT ((0.0)) FOR [DiscountRate]
GO
ALTER TABLE [dbo].[PurchaseOrderItems] ADD  DEFAULT (CONVERT([bit],(0))) FOR [IsTaxInclusive]
GO
ALTER TABLE [dbo].[PurchaseOrderItems] ADD  DEFAULT ((0.0)) FOR [SubTotal]
GO
ALTER TABLE [dbo].[PurchaseOrderItems] ADD  DEFAULT ((0.0)) FOR [TaxAmount]
GO
ALTER TABLE [dbo].[PurchaseOrderItems] ADD  DEFAULT ((0.0)) FOR [TaxRate]
GO
ALTER TABLE [dbo].[PurchaseOrders] ADD  DEFAULT (N'USD') FOR [Currency]
GO
ALTER TABLE [dbo].[PurchaseOrders] ADD  DEFAULT ((0.0)) FOR [DiscountAmount]
GO
ALTER TABLE [dbo].[PurchaseOrders] ADD  DEFAULT ((0.0)) FOR [SubTotal]
GO
ALTER TABLE [dbo].[PurchaseOrders] ADD  DEFAULT ((0.0)) FOR [TaxAmount]
GO
ALTER TABLE [dbo].[SalesInvoiceItems] ADD  DEFAULT (CONVERT([bit],(0))) FOR [IsTaxInclusive]
GO
ALTER TABLE [dbo].[SalesOrderItems] ADD  DEFAULT ((0.0)) FOR [DiscountRate]
GO
ALTER TABLE [dbo].[SalesOrderItems] ADD  DEFAULT ((0.0)) FOR [DiscountAmount]
GO
ALTER TABLE [dbo].[SalesOrderItems] ADD  DEFAULT ((0.0)) FOR [TaxRate]
GO
ALTER TABLE [dbo].[SalesOrderItems] ADD  DEFAULT ((0.0)) FOR [TaxAmount]
GO
ALTER TABLE [dbo].[SalesOrderItems] ADD  DEFAULT (CONVERT([bit],(0))) FOR [IsTaxInclusive]
GO
ALTER TABLE [dbo].[TaxCodes] ADD  DEFAULT (CONVERT([bit],(1))) FOR [IsActive]
GO
ALTER TABLE [dbo].[Addresses]  WITH CHECK ADD  CONSTRAINT [FK_Addresses_Countries_CountryId] FOREIGN KEY([CountryId])
REFERENCES [dbo].[Countries] ([CountryId])
GO
ALTER TABLE [dbo].[Addresses] CHECK CONSTRAINT [FK_Addresses_Countries_CountryId]
GO
ALTER TABLE [dbo].[BranchAddresses]  WITH CHECK ADD  CONSTRAINT [FK_BranchAddresses_Addresses_TenantId_AddressId] FOREIGN KEY([TenantId], [AddressId])
REFERENCES [dbo].[Addresses] ([TenantId], [AddressId])
GO
ALTER TABLE [dbo].[BranchAddresses] CHECK CONSTRAINT [FK_BranchAddresses_Addresses_TenantId_AddressId]
GO
ALTER TABLE [dbo].[BranchAddresses]  WITH CHECK ADD  CONSTRAINT [FK_BranchAddresses_AddressTypes_AddressTypeId] FOREIGN KEY([AddressTypeId])
REFERENCES [dbo].[AddressTypes] ([AddressTypeId])
GO
ALTER TABLE [dbo].[BranchAddresses] CHECK CONSTRAINT [FK_BranchAddresses_AddressTypes_AddressTypeId]
GO
ALTER TABLE [dbo].[BranchAddresses]  WITH CHECK ADD  CONSTRAINT [FK_BranchAddresses_Branches_BranchId] FOREIGN KEY([BranchId])
REFERENCES [dbo].[Branches] ([Id])
GO
ALTER TABLE [dbo].[BranchAddresses] CHECK CONSTRAINT [FK_BranchAddresses_Branches_BranchId]
GO
ALTER TABLE [dbo].[CompanyAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CompanyAddresses_Addresses_TenantId_AddressId] FOREIGN KEY([TenantId], [AddressId])
REFERENCES [dbo].[Addresses] ([TenantId], [AddressId])
GO
ALTER TABLE [dbo].[CompanyAddresses] CHECK CONSTRAINT [FK_CompanyAddresses_Addresses_TenantId_AddressId]
GO
ALTER TABLE [dbo].[CompanyAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CompanyAddresses_AddressTypes_AddressTypeId] FOREIGN KEY([AddressTypeId])
REFERENCES [dbo].[AddressTypes] ([AddressTypeId])
GO
ALTER TABLE [dbo].[CompanyAddresses] CHECK CONSTRAINT [FK_CompanyAddresses_AddressTypes_AddressTypeId]
GO
ALTER TABLE [dbo].[CompanyAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CompanyAddresses_Companies_TenantId_CompanyId] FOREIGN KEY([TenantId], [CompanyId])
REFERENCES [dbo].[Companies] ([TenantId], [Id])
GO
ALTER TABLE [dbo].[CompanyAddresses] CHECK CONSTRAINT [FK_CompanyAddresses_Companies_TenantId_CompanyId]
GO
ALTER TABLE [dbo].[CustomerAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CustomerAddresses_Addresses_TenantId_AddressId] FOREIGN KEY([TenantId], [AddressId])
REFERENCES [dbo].[Addresses] ([TenantId], [AddressId])
GO
ALTER TABLE [dbo].[CustomerAddresses] CHECK CONSTRAINT [FK_CustomerAddresses_Addresses_TenantId_AddressId]
GO
ALTER TABLE [dbo].[CustomerAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CustomerAddresses_AddressTypes_AddressTypeId] FOREIGN KEY([AddressTypeId])
REFERENCES [dbo].[AddressTypes] ([AddressTypeId])
GO
ALTER TABLE [dbo].[CustomerAddresses] CHECK CONSTRAINT [FK_CustomerAddresses_AddressTypes_AddressTypeId]
GO
ALTER TABLE [dbo].[CustomerAddresses]  WITH CHECK ADD  CONSTRAINT [FK_CustomerAddresses_Customers_TenantId_CustomerId] FOREIGN KEY([TenantId], [CustomerId])
REFERENCES [dbo].[Customers] ([TenantId], [CustomerId])
GO
ALTER TABLE [dbo].[CustomerAddresses] CHECK CONSTRAINT [FK_CustomerAddresses_Customers_TenantId_CustomerId]
GO
ALTER TABLE [dbo].[CustomerContacts]  WITH CHECK ADD  CONSTRAINT [FK_CustomerContacts_Contacts_TenantId_ContactId] FOREIGN KEY([TenantId], [ContactId])
REFERENCES [dbo].[Contacts] ([TenantId], [ContactId])
GO
ALTER TABLE [dbo].[CustomerContacts] CHECK CONSTRAINT [FK_CustomerContacts_Contacts_TenantId_ContactId]
GO
ALTER TABLE [dbo].[CustomerContacts]  WITH CHECK ADD  CONSTRAINT [FK_CustomerContacts_ContactTypes_ContactTypeId] FOREIGN KEY([ContactTypeId])
REFERENCES [dbo].[ContactTypes] ([ContactTypeId])
GO
ALTER TABLE [dbo].[CustomerContacts] CHECK CONSTRAINT [FK_CustomerContacts_ContactTypes_ContactTypeId]
GO
ALTER TABLE [dbo].[CustomerContacts]  WITH CHECK ADD  CONSTRAINT [FK_CustomerContacts_Customers_TenantId_CustomerId] FOREIGN KEY([TenantId], [CustomerId])
REFERENCES [dbo].[Customers] ([TenantId], [CustomerId])
GO
ALTER TABLE [dbo].[CustomerContacts] CHECK CONSTRAINT [FK_CustomerContacts_Customers_TenantId_CustomerId]
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines]  WITH CHECK ADD  CONSTRAINT [FK_GoodsReceiptNoteLines_GoodsReceiptNotes_GoodsReceiptNoteId] FOREIGN KEY([GoodsReceiptNoteId])
REFERENCES [dbo].[GoodsReceiptNotes] ([GoodsReceiptNoteId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines] CHECK CONSTRAINT [FK_GoodsReceiptNoteLines_GoodsReceiptNotes_GoodsReceiptNoteId]
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines]  WITH CHECK ADD  CONSTRAINT [FK_GoodsReceiptNoteLines_Products_ProductId] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Products] ([ProductId])
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines] CHECK CONSTRAINT [FK_GoodsReceiptNoteLines_Products_ProductId]
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines]  WITH CHECK ADD  CONSTRAINT [FK_GoodsReceiptNoteLines_PurchaseOrderItems_PurchaseOrderItemId] FOREIGN KEY([PurchaseOrderItemId])
REFERENCES [dbo].[PurchaseOrderItems] ([Id])
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines] CHECK CONSTRAINT [FK_GoodsReceiptNoteLines_PurchaseOrderItems_PurchaseOrderItemId]
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines]  WITH CHECK ADD  CONSTRAINT [FK_GoodsReceiptNoteLines_WarehouseLocations_WarehouseLocationId] FOREIGN KEY([WarehouseLocationId])
REFERENCES [dbo].[WarehouseLocations] ([WarehouseLocationId])
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines] CHECK CONSTRAINT [FK_GoodsReceiptNoteLines_WarehouseLocations_WarehouseLocationId]
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines]  WITH CHECK ADD  CONSTRAINT [FK_GoodsReceiptNoteLines_Warehouses_WarehouseId] FOREIGN KEY([WarehouseId])
REFERENCES [dbo].[Warehouses] ([WarehouseId])
GO
ALTER TABLE [dbo].[GoodsReceiptNoteLines] CHECK CONSTRAINT [FK_GoodsReceiptNoteLines_Warehouses_WarehouseId]
GO
ALTER TABLE [dbo].[GoodsReceiptNotes]  WITH CHECK ADD  CONSTRAINT [FK_GoodsReceiptNotes_PurchaseOrders_PurchaseOrderId] FOREIGN KEY([PurchaseOrderId])
REFERENCES [dbo].[PurchaseOrders] ([Id])
GO
ALTER TABLE [dbo].[GoodsReceiptNotes] CHECK CONSTRAINT [FK_GoodsReceiptNotes_PurchaseOrders_PurchaseOrderId]
GO
ALTER TABLE [dbo].[InventoryBalances]  WITH CHECK ADD  CONSTRAINT [FK_InventoryBalances_Products_TenantId_ProductId] FOREIGN KEY([TenantId], [ProductId])
REFERENCES [dbo].[Products] ([TenantId], [ProductId])
GO
ALTER TABLE [dbo].[InventoryBalances] CHECK CONSTRAINT [FK_InventoryBalances_Products_TenantId_ProductId]
GO
ALTER TABLE [dbo].[InventoryBalances]  WITH CHECK ADD  CONSTRAINT [FK_InventoryBalances_WarehouseLocations_TenantId_WarehouseId_WarehouseLocationId] FOREIGN KEY([TenantId], [WarehouseId], [WarehouseLocationId])
REFERENCES [dbo].[WarehouseLocations] ([TenantId], [WarehouseId], [WarehouseLocationId])
GO
ALTER TABLE [dbo].[InventoryBalances] CHECK CONSTRAINT [FK_InventoryBalances_WarehouseLocations_TenantId_WarehouseId_WarehouseLocationId]
GO
ALTER TABLE [dbo].[InventoryBalances]  WITH CHECK ADD  CONSTRAINT [FK_InventoryBalances_Warehouses_TenantId_WarehouseId] FOREIGN KEY([TenantId], [WarehouseId])
REFERENCES [dbo].[Warehouses] ([TenantId], [WarehouseId])
GO
ALTER TABLE [dbo].[InventoryBalances] CHECK CONSTRAINT [FK_InventoryBalances_Warehouses_TenantId_WarehouseId]
GO
ALTER TABLE [dbo].[InventoryCostLayers]  WITH CHECK ADD  CONSTRAINT [FK_InventoryCostLayers_InventoryTransactions_InventoryTransactionId] FOREIGN KEY([InventoryTransactionId])
REFERENCES [dbo].[InventoryTransactions] ([InventoryTransactionId])
GO
ALTER TABLE [dbo].[InventoryCostLayers] CHECK CONSTRAINT [FK_InventoryCostLayers_InventoryTransactions_InventoryTransactionId]
GO
ALTER TABLE [dbo].[InventoryCostLayers]  WITH CHECK ADD  CONSTRAINT [FK_InventoryCostLayers_Products_TenantId_ProductId] FOREIGN KEY([TenantId], [ProductId])
REFERENCES [dbo].[Products] ([TenantId], [ProductId])
GO
ALTER TABLE [dbo].[InventoryCostLayers] CHECK CONSTRAINT [FK_InventoryCostLayers_Products_TenantId_ProductId]
GO
ALTER TABLE [dbo].[InventoryCostLayers]  WITH CHECK ADD  CONSTRAINT [FK_InventoryCostLayers_WarehouseLocations_TenantId_WarehouseId_WarehouseLocationId] FOREIGN KEY([TenantId], [WarehouseId], [WarehouseLocationId])
REFERENCES [dbo].[WarehouseLocations] ([TenantId], [WarehouseId], [WarehouseLocationId])
GO
ALTER TABLE [dbo].[InventoryCostLayers] CHECK CONSTRAINT [FK_InventoryCostLayers_WarehouseLocations_TenantId_WarehouseId_WarehouseLocationId]
GO
ALTER TABLE [dbo].[InventoryCostLayers]  WITH CHECK ADD  CONSTRAINT [FK_InventoryCostLayers_Warehouses_TenantId_WarehouseId] FOREIGN KEY([TenantId], [WarehouseId])
REFERENCES [dbo].[Warehouses] ([TenantId], [WarehouseId])
GO
ALTER TABLE [dbo].[InventoryCostLayers] CHECK CONSTRAINT [FK_InventoryCostLayers_Warehouses_TenantId_WarehouseId]
GO
ALTER TABLE [dbo].[InventoryTransactions]  WITH CHECK ADD  CONSTRAINT [FK_InventoryTransactions_InventoryTransactions_ReversalOfTransactionId] FOREIGN KEY([ReversalOfTransactionId])
REFERENCES [dbo].[InventoryTransactions] ([InventoryTransactionId])
GO
ALTER TABLE [dbo].[InventoryTransactions] CHECK CONSTRAINT [FK_InventoryTransactions_InventoryTransactions_ReversalOfTransactionId]
GO
ALTER TABLE [dbo].[InventoryTransactions]  WITH CHECK ADD  CONSTRAINT [FK_InventoryTransactions_Products_TenantId_ProductId] FOREIGN KEY([TenantId], [ProductId])
REFERENCES [dbo].[Products] ([TenantId], [ProductId])
GO
ALTER TABLE [dbo].[InventoryTransactions] CHECK CONSTRAINT [FK_InventoryTransactions_Products_TenantId_ProductId]
GO
ALTER TABLE [dbo].[InventoryTransactions]  WITH CHECK ADD  CONSTRAINT [FK_InventoryTransactions_WarehouseLocations_TenantId_WarehouseId_WarehouseLocationId] FOREIGN KEY([TenantId], [WarehouseId], [WarehouseLocationId])
REFERENCES [dbo].[WarehouseLocations] ([TenantId], [WarehouseId], [WarehouseLocationId])
GO
ALTER TABLE [dbo].[InventoryTransactions] CHECK CONSTRAINT [FK_InventoryTransactions_WarehouseLocations_TenantId_WarehouseId_WarehouseLocationId]
GO
ALTER TABLE [dbo].[InventoryTransactions]  WITH CHECK ADD  CONSTRAINT [FK_InventoryTransactions_Warehouses_TenantId_WarehouseId] FOREIGN KEY([TenantId], [WarehouseId])
REFERENCES [dbo].[Warehouses] ([TenantId], [WarehouseId])
GO
ALTER TABLE [dbo].[InventoryTransactions] CHECK CONSTRAINT [FK_InventoryTransactions_Warehouses_TenantId_WarehouseId]
GO
ALTER TABLE [dbo].[ProductBatches]  WITH CHECK ADD  CONSTRAINT [FK_ProductBatches_Products_TenantId_ProductId] FOREIGN KEY([TenantId], [ProductId])
REFERENCES [dbo].[Products] ([TenantId], [ProductId])
GO
ALTER TABLE [dbo].[ProductBatches] CHECK CONSTRAINT [FK_ProductBatches_Products_TenantId_ProductId]
GO
ALTER TABLE [dbo].[Products]  WITH CHECK ADD  CONSTRAINT [FK_Products_Categories_TenantId_CategoryId] FOREIGN KEY([TenantId], [CategoryId])
REFERENCES [dbo].[Categories] ([TenantId], [CategoryId])
GO
ALTER TABLE [dbo].[Products] CHECK CONSTRAINT [FK_Products_Categories_TenantId_CategoryId]
GO
ALTER TABLE [dbo].[Products]  WITH CHECK ADD  CONSTRAINT [FK_Products_UnitsOfMeasure_TenantId_UnitOfMeasureId] FOREIGN KEY([TenantId], [UnitOfMeasureId])
REFERENCES [dbo].[UnitsOfMeasure] ([TenantId], [UnitOfMeasureId])
GO
ALTER TABLE [dbo].[Products] CHECK CONSTRAINT [FK_Products_UnitsOfMeasure_TenantId_UnitOfMeasureId]
GO
ALTER TABLE [dbo].[ProductValuationBalances]  WITH CHECK ADD  CONSTRAINT [FK_ProductValuationBalances_Products_TenantId_ProductId] FOREIGN KEY([TenantId], [ProductId])
REFERENCES [dbo].[Products] ([TenantId], [ProductId])
GO
ALTER TABLE [dbo].[ProductValuationBalances] CHECK CONSTRAINT [FK_ProductValuationBalances_Products_TenantId_ProductId]
GO
ALTER TABLE [dbo].[ProductValuationBalances]  WITH CHECK ADD  CONSTRAINT [FK_ProductValuationBalances_Warehouses_TenantId_WarehouseId] FOREIGN KEY([TenantId], [WarehouseId])
REFERENCES [dbo].[Warehouses] ([TenantId], [WarehouseId])
GO
ALTER TABLE [dbo].[ProductValuationBalances] CHECK CONSTRAINT [FK_ProductValuationBalances_Warehouses_TenantId_WarehouseId]
GO
ALTER TABLE [dbo].[ProductWarehouseSettings]  WITH CHECK ADD  CONSTRAINT [FK_ProductWarehouseSettings_Products_TenantId_ProductId] FOREIGN KEY([TenantId], [ProductId])
REFERENCES [dbo].[Products] ([TenantId], [ProductId])
GO
ALTER TABLE [dbo].[ProductWarehouseSettings] CHECK CONSTRAINT [FK_ProductWarehouseSettings_Products_TenantId_ProductId]
GO
ALTER TABLE [dbo].[ProductWarehouseSettings]  WITH CHECK ADD  CONSTRAINT [FK_ProductWarehouseSettings_Warehouses_TenantId_WarehouseId] FOREIGN KEY([TenantId], [WarehouseId])
REFERENCES [dbo].[Warehouses] ([TenantId], [WarehouseId])
GO
ALTER TABLE [dbo].[ProductWarehouseSettings] CHECK CONSTRAINT [FK_ProductWarehouseSettings_Warehouses_TenantId_WarehouseId]
GO
ALTER TABLE [dbo].[PurchaseOrderItems]  WITH CHECK ADD  CONSTRAINT [FK_PurchaseOrderItems_Products_ProductId] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Products] ([ProductId])
GO
ALTER TABLE [dbo].[PurchaseOrderItems] CHECK CONSTRAINT [FK_PurchaseOrderItems_Products_ProductId]
GO
ALTER TABLE [dbo].[PurchaseOrderItems]  WITH CHECK ADD  CONSTRAINT [FK_PurchaseOrderItems_PurchaseOrders_PurchaseOrderId] FOREIGN KEY([PurchaseOrderId])
REFERENCES [dbo].[PurchaseOrders] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PurchaseOrderItems] CHECK CONSTRAINT [FK_PurchaseOrderItems_PurchaseOrders_PurchaseOrderId]
GO
ALTER TABLE [dbo].[PurchaseOrderItems]  WITH CHECK ADD  CONSTRAINT [FK_PurchaseOrderItems_UnitsOfMeasure_UnitOfMeasureId] FOREIGN KEY([UnitOfMeasureId])
REFERENCES [dbo].[UnitsOfMeasure] ([UnitOfMeasureId])
GO
ALTER TABLE [dbo].[PurchaseOrderItems] CHECK CONSTRAINT [FK_PurchaseOrderItems_UnitsOfMeasure_UnitOfMeasureId]
GO
ALTER TABLE [dbo].[PurchaseOrders]  WITH CHECK ADD  CONSTRAINT [FK_PurchaseOrders_Suppliers_SupplierId] FOREIGN KEY([SupplierId])
REFERENCES [dbo].[Suppliers] ([SupplierId])
GO
ALTER TABLE [dbo].[PurchaseOrders] CHECK CONSTRAINT [FK_PurchaseOrders_Suppliers_SupplierId]
GO
ALTER TABLE [dbo].[PurchaseRequisitionItems]  WITH CHECK ADD  CONSTRAINT [FK_PurchaseRequisitionItems_Products_ProductId] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Products] ([ProductId])
GO
ALTER TABLE [dbo].[PurchaseRequisitionItems] CHECK CONSTRAINT [FK_PurchaseRequisitionItems_Products_ProductId]
GO
ALTER TABLE [dbo].[PurchaseRequisitionItems]  WITH CHECK ADD  CONSTRAINT [FK_PurchaseRequisitionItems_PurchaseRequisitions_PurchaseRequisitionId] FOREIGN KEY([PurchaseRequisitionId])
REFERENCES [dbo].[PurchaseRequisitions] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PurchaseRequisitionItems] CHECK CONSTRAINT [FK_PurchaseRequisitionItems_PurchaseRequisitions_PurchaseRequisitionId]
GO
ALTER TABLE [dbo].[PurchaseRequisitionItems]  WITH CHECK ADD  CONSTRAINT [FK_PurchaseRequisitionItems_UnitsOfMeasure_UnitOfMeasureId] FOREIGN KEY([UnitOfMeasureId])
REFERENCES [dbo].[UnitsOfMeasure] ([UnitOfMeasureId])
GO
ALTER TABLE [dbo].[PurchaseRequisitionItems] CHECK CONSTRAINT [FK_PurchaseRequisitionItems_UnitsOfMeasure_UnitOfMeasureId]
GO
ALTER TABLE [dbo].[PutawayLineAllocations]  WITH CHECK ADD  CONSTRAINT [FK_PutawayLineAllocations_PutawayLines_PutawayLineId] FOREIGN KEY([PutawayLineId])
REFERENCES [dbo].[PutawayLines] ([PutawayLineId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PutawayLineAllocations] CHECK CONSTRAINT [FK_PutawayLineAllocations_PutawayLines_PutawayLineId]
GO
ALTER TABLE [dbo].[PutawayLines]  WITH CHECK ADD  CONSTRAINT [FK_PutawayLines_Putaways_PutawayId] FOREIGN KEY([PutawayId])
REFERENCES [dbo].[Putaways] ([PutawayId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PutawayLines] CHECK CONSTRAINT [FK_PutawayLines_Putaways_PutawayId]
GO
ALTER TABLE [dbo].[SalesInvoiceItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoiceItems_Products_ProductId] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Products] ([ProductId])
GO
ALTER TABLE [dbo].[SalesInvoiceItems] CHECK CONSTRAINT [FK_SalesInvoiceItems_Products_ProductId]
GO
ALTER TABLE [dbo].[SalesInvoiceItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoiceItems_SalesInvoices_SalesInvoiceId] FOREIGN KEY([SalesInvoiceId])
REFERENCES [dbo].[SalesInvoices] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[SalesInvoiceItems] CHECK CONSTRAINT [FK_SalesInvoiceItems_SalesInvoices_SalesInvoiceId]
GO
ALTER TABLE [dbo].[SalesInvoiceItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoiceItems_SalesOrderItems_SalesOrderItemId] FOREIGN KEY([SalesOrderItemId])
REFERENCES [dbo].[SalesOrderItems] ([Id])
GO
ALTER TABLE [dbo].[SalesInvoiceItems] CHECK CONSTRAINT [FK_SalesInvoiceItems_SalesOrderItems_SalesOrderItemId]
GO
ALTER TABLE [dbo].[SalesInvoiceItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoiceItems_SalesShipmentItems_SalesShipmentItemId] FOREIGN KEY([SalesShipmentItemId])
REFERENCES [dbo].[SalesShipmentItems] ([Id])
GO
ALTER TABLE [dbo].[SalesInvoiceItems] CHECK CONSTRAINT [FK_SalesInvoiceItems_SalesShipmentItems_SalesShipmentItemId]
GO
ALTER TABLE [dbo].[SalesInvoiceItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoiceItems_UnitsOfMeasure_UnitOfMeasureId] FOREIGN KEY([UnitOfMeasureId])
REFERENCES [dbo].[UnitsOfMeasure] ([UnitOfMeasureId])
GO
ALTER TABLE [dbo].[SalesInvoiceItems] CHECK CONSTRAINT [FK_SalesInvoiceItems_UnitsOfMeasure_UnitOfMeasureId]
GO
ALTER TABLE [dbo].[SalesInvoices]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoices_Branches_BranchId] FOREIGN KEY([BranchId])
REFERENCES [dbo].[Branches] ([Id])
GO
ALTER TABLE [dbo].[SalesInvoices] CHECK CONSTRAINT [FK_SalesInvoices_Branches_BranchId]
GO
ALTER TABLE [dbo].[SalesInvoices]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoices_Companies_TenantId_CompanyId] FOREIGN KEY([TenantId], [CompanyId])
REFERENCES [dbo].[Companies] ([TenantId], [Id])
GO
ALTER TABLE [dbo].[SalesInvoices] CHECK CONSTRAINT [FK_SalesInvoices_Companies_TenantId_CompanyId]
GO
ALTER TABLE [dbo].[SalesInvoices]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoices_Customers_CustomerId] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customers] ([CustomerId])
GO
ALTER TABLE [dbo].[SalesInvoices] CHECK CONSTRAINT [FK_SalesInvoices_Customers_CustomerId]
GO
ALTER TABLE [dbo].[SalesInvoices]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoices_SalesOrders_SalesOrderId] FOREIGN KEY([SalesOrderId])
REFERENCES [dbo].[SalesOrders] ([Id])
GO
ALTER TABLE [dbo].[SalesInvoices] CHECK CONSTRAINT [FK_SalesInvoices_SalesOrders_SalesOrderId]
GO
ALTER TABLE [dbo].[SalesInvoices]  WITH CHECK ADD  CONSTRAINT [FK_SalesInvoices_SalesShipments_SalesShipmentId] FOREIGN KEY([SalesShipmentId])
REFERENCES [dbo].[SalesShipments] ([Id])
GO
ALTER TABLE [dbo].[SalesInvoices] CHECK CONSTRAINT [FK_SalesInvoices_SalesShipments_SalesShipmentId]
GO
ALTER TABLE [dbo].[SalesOrderItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesOrderItems_Products_ProductId] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Products] ([ProductId])
GO
ALTER TABLE [dbo].[SalesOrderItems] CHECK CONSTRAINT [FK_SalesOrderItems_Products_ProductId]
GO
ALTER TABLE [dbo].[SalesOrderItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesOrderItems_SalesOrders_SalesOrderId] FOREIGN KEY([SalesOrderId])
REFERENCES [dbo].[SalesOrders] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[SalesOrderItems] CHECK CONSTRAINT [FK_SalesOrderItems_SalesOrders_SalesOrderId]
GO
ALTER TABLE [dbo].[SalesOrderItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesOrderItems_UnitsOfMeasure_UnitOfMeasureId] FOREIGN KEY([UnitOfMeasureId])
REFERENCES [dbo].[UnitsOfMeasure] ([UnitOfMeasureId])
GO
ALTER TABLE [dbo].[SalesOrderItems] CHECK CONSTRAINT [FK_SalesOrderItems_UnitsOfMeasure_UnitOfMeasureId]
GO
ALTER TABLE [dbo].[SalesOrders]  WITH CHECK ADD  CONSTRAINT [FK_SalesOrders_Branches_BranchId] FOREIGN KEY([BranchId])
REFERENCES [dbo].[Branches] ([Id])
GO
ALTER TABLE [dbo].[SalesOrders] CHECK CONSTRAINT [FK_SalesOrders_Branches_BranchId]
GO
ALTER TABLE [dbo].[SalesOrders]  WITH CHECK ADD  CONSTRAINT [FK_SalesOrders_Companies_TenantId_CompanyId] FOREIGN KEY([TenantId], [CompanyId])
REFERENCES [dbo].[Companies] ([TenantId], [Id])
GO
ALTER TABLE [dbo].[SalesOrders] CHECK CONSTRAINT [FK_SalesOrders_Companies_TenantId_CompanyId]
GO
ALTER TABLE [dbo].[SalesOrders]  WITH CHECK ADD  CONSTRAINT [FK_SalesOrders_Customers_CustomerId] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customers] ([CustomerId])
GO
ALTER TABLE [dbo].[SalesOrders] CHECK CONSTRAINT [FK_SalesOrders_Customers_CustomerId]
GO
ALTER TABLE [dbo].[SalesShipmentItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipmentItems_Products_ProductId] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Products] ([ProductId])
GO
ALTER TABLE [dbo].[SalesShipmentItems] CHECK CONSTRAINT [FK_SalesShipmentItems_Products_ProductId]
GO
ALTER TABLE [dbo].[SalesShipmentItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipmentItems_SalesOrderItems_SalesOrderItemId] FOREIGN KEY([SalesOrderItemId])
REFERENCES [dbo].[SalesOrderItems] ([Id])
GO
ALTER TABLE [dbo].[SalesShipmentItems] CHECK CONSTRAINT [FK_SalesShipmentItems_SalesOrderItems_SalesOrderItemId]
GO
ALTER TABLE [dbo].[SalesShipmentItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipmentItems_SalesShipments_SalesShipmentId] FOREIGN KEY([SalesShipmentId])
REFERENCES [dbo].[SalesShipments] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[SalesShipmentItems] CHECK CONSTRAINT [FK_SalesShipmentItems_SalesShipments_SalesShipmentId]
GO
ALTER TABLE [dbo].[SalesShipmentItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipmentItems_UnitsOfMeasure_UnitOfMeasureId] FOREIGN KEY([UnitOfMeasureId])
REFERENCES [dbo].[UnitsOfMeasure] ([UnitOfMeasureId])
GO
ALTER TABLE [dbo].[SalesShipmentItems] CHECK CONSTRAINT [FK_SalesShipmentItems_UnitsOfMeasure_UnitOfMeasureId]
GO
ALTER TABLE [dbo].[SalesShipmentItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipmentItems_WarehouseLocations_WarehouseLocationId] FOREIGN KEY([WarehouseLocationId])
REFERENCES [dbo].[WarehouseLocations] ([WarehouseLocationId])
GO
ALTER TABLE [dbo].[SalesShipmentItems] CHECK CONSTRAINT [FK_SalesShipmentItems_WarehouseLocations_WarehouseLocationId]
GO
ALTER TABLE [dbo].[SalesShipmentItems]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipmentItems_Warehouses_WarehouseId] FOREIGN KEY([WarehouseId])
REFERENCES [dbo].[Warehouses] ([WarehouseId])
GO
ALTER TABLE [dbo].[SalesShipmentItems] CHECK CONSTRAINT [FK_SalesShipmentItems_Warehouses_WarehouseId]
GO
ALTER TABLE [dbo].[SalesShipments]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipments_Branches_BranchId] FOREIGN KEY([BranchId])
REFERENCES [dbo].[Branches] ([Id])
GO
ALTER TABLE [dbo].[SalesShipments] CHECK CONSTRAINT [FK_SalesShipments_Branches_BranchId]
GO
ALTER TABLE [dbo].[SalesShipments]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipments_Companies_TenantId_CompanyId] FOREIGN KEY([TenantId], [CompanyId])
REFERENCES [dbo].[Companies] ([TenantId], [Id])
GO
ALTER TABLE [dbo].[SalesShipments] CHECK CONSTRAINT [FK_SalesShipments_Companies_TenantId_CompanyId]
GO
ALTER TABLE [dbo].[SalesShipments]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipments_Customers_CustomerId] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customers] ([CustomerId])
GO
ALTER TABLE [dbo].[SalesShipments] CHECK CONSTRAINT [FK_SalesShipments_Customers_CustomerId]
GO
ALTER TABLE [dbo].[SalesShipments]  WITH CHECK ADD  CONSTRAINT [FK_SalesShipments_SalesOrders_SalesOrderId] FOREIGN KEY([SalesOrderId])
REFERENCES [dbo].[SalesOrders] ([Id])
GO
ALTER TABLE [dbo].[SalesShipments] CHECK CONSTRAINT [FK_SalesShipments_SalesOrders_SalesOrderId]
GO
ALTER TABLE [dbo].[SupplierAddresses]  WITH CHECK ADD  CONSTRAINT [FK_SupplierAddresses_Addresses_TenantId_AddressId] FOREIGN KEY([TenantId], [AddressId])
REFERENCES [dbo].[Addresses] ([TenantId], [AddressId])
GO
ALTER TABLE [dbo].[SupplierAddresses] CHECK CONSTRAINT [FK_SupplierAddresses_Addresses_TenantId_AddressId]
GO
ALTER TABLE [dbo].[SupplierAddresses]  WITH CHECK ADD  CONSTRAINT [FK_SupplierAddresses_AddressTypes_AddressTypeId] FOREIGN KEY([AddressTypeId])
REFERENCES [dbo].[AddressTypes] ([AddressTypeId])
GO
ALTER TABLE [dbo].[SupplierAddresses] CHECK CONSTRAINT [FK_SupplierAddresses_AddressTypes_AddressTypeId]
GO
ALTER TABLE [dbo].[SupplierAddresses]  WITH CHECK ADD  CONSTRAINT [FK_SupplierAddresses_Suppliers_TenantId_SupplierId] FOREIGN KEY([TenantId], [SupplierId])
REFERENCES [dbo].[Suppliers] ([TenantId], [SupplierId])
GO
ALTER TABLE [dbo].[SupplierAddresses] CHECK CONSTRAINT [FK_SupplierAddresses_Suppliers_TenantId_SupplierId]
GO
ALTER TABLE [dbo].[SupplierContacts]  WITH CHECK ADD  CONSTRAINT [FK_SupplierContacts_Contacts_TenantId_ContactId] FOREIGN KEY([TenantId], [ContactId])
REFERENCES [dbo].[Contacts] ([TenantId], [ContactId])
GO
ALTER TABLE [dbo].[SupplierContacts] CHECK CONSTRAINT [FK_SupplierContacts_Contacts_TenantId_ContactId]
GO
ALTER TABLE [dbo].[SupplierContacts]  WITH CHECK ADD  CONSTRAINT [FK_SupplierContacts_ContactTypes_ContactTypeId] FOREIGN KEY([ContactTypeId])
REFERENCES [dbo].[ContactTypes] ([ContactTypeId])
GO
ALTER TABLE [dbo].[SupplierContacts] CHECK CONSTRAINT [FK_SupplierContacts_ContactTypes_ContactTypeId]
GO
ALTER TABLE [dbo].[SupplierContacts]  WITH CHECK ADD  CONSTRAINT [FK_SupplierContacts_Suppliers_TenantId_SupplierId] FOREIGN KEY([TenantId], [SupplierId])
REFERENCES [dbo].[Suppliers] ([TenantId], [SupplierId])
GO
ALTER TABLE [dbo].[SupplierContacts] CHECK CONSTRAINT [FK_SupplierContacts_Suppliers_TenantId_SupplierId]
GO
ALTER TABLE [dbo].[SupplierProductPrices]  WITH CHECK ADD  CONSTRAINT [FK_SupplierProductPrices_Products_TenantId_ProductId] FOREIGN KEY([TenantId], [ProductId])
REFERENCES [dbo].[Products] ([TenantId], [ProductId])
GO
ALTER TABLE [dbo].[SupplierProductPrices] CHECK CONSTRAINT [FK_SupplierProductPrices_Products_TenantId_ProductId]
GO
ALTER TABLE [dbo].[SupplierProductPrices]  WITH CHECK ADD  CONSTRAINT [FK_SupplierProductPrices_Suppliers_TenantId_SupplierId] FOREIGN KEY([TenantId], [SupplierId])
REFERENCES [dbo].[Suppliers] ([TenantId], [SupplierId])
GO
ALTER TABLE [dbo].[SupplierProductPrices] CHECK CONSTRAINT [FK_SupplierProductPrices_Suppliers_TenantId_SupplierId]
GO
ALTER TABLE [dbo].[SupplierProductPrices]  WITH CHECK ADD  CONSTRAINT [FK_SupplierProductPrices_UnitsOfMeasure_TenantId_UnitOfMeasureId] FOREIGN KEY([TenantId], [UnitOfMeasureId])
REFERENCES [dbo].[UnitsOfMeasure] ([TenantId], [UnitOfMeasureId])
GO
ALTER TABLE [dbo].[SupplierProductPrices] CHECK CONSTRAINT [FK_SupplierProductPrices_UnitsOfMeasure_TenantId_UnitOfMeasureId]
GO
ALTER TABLE [dbo].[UnitOfMeasureConversions]  WITH CHECK ADD  CONSTRAINT [FK_UnitOfMeasureConversions_UnitsOfMeasure_TenantId_FromUnitId] FOREIGN KEY([TenantId], [FromUnitId])
REFERENCES [dbo].[UnitsOfMeasure] ([TenantId], [UnitOfMeasureId])
GO
ALTER TABLE [dbo].[UnitOfMeasureConversions] CHECK CONSTRAINT [FK_UnitOfMeasureConversions_UnitsOfMeasure_TenantId_FromUnitId]
GO
ALTER TABLE [dbo].[UnitOfMeasureConversions]  WITH CHECK ADD  CONSTRAINT [FK_UnitOfMeasureConversions_UnitsOfMeasure_TenantId_ToUnitId] FOREIGN KEY([TenantId], [ToUnitId])
REFERENCES [dbo].[UnitsOfMeasure] ([TenantId], [UnitOfMeasureId])
GO
ALTER TABLE [dbo].[UnitOfMeasureConversions] CHECK CONSTRAINT [FK_UnitOfMeasureConversions_UnitsOfMeasure_TenantId_ToUnitId]
GO
ALTER TABLE [dbo].[WarehouseAddresses]  WITH CHECK ADD  CONSTRAINT [FK_WarehouseAddresses_Addresses_TenantId_AddressId] FOREIGN KEY([TenantId], [AddressId])
REFERENCES [dbo].[Addresses] ([TenantId], [AddressId])
GO
ALTER TABLE [dbo].[WarehouseAddresses] CHECK CONSTRAINT [FK_WarehouseAddresses_Addresses_TenantId_AddressId]
GO
ALTER TABLE [dbo].[WarehouseAddresses]  WITH CHECK ADD  CONSTRAINT [FK_WarehouseAddresses_AddressTypes_AddressTypeId] FOREIGN KEY([AddressTypeId])
REFERENCES [dbo].[AddressTypes] ([AddressTypeId])
GO
ALTER TABLE [dbo].[WarehouseAddresses] CHECK CONSTRAINT [FK_WarehouseAddresses_AddressTypes_AddressTypeId]
GO
ALTER TABLE [dbo].[WarehouseAddresses]  WITH CHECK ADD  CONSTRAINT [FK_WarehouseAddresses_Warehouses_TenantId_WarehouseId] FOREIGN KEY([TenantId], [WarehouseId])
REFERENCES [dbo].[Warehouses] ([TenantId], [WarehouseId])
GO
ALTER TABLE [dbo].[WarehouseAddresses] CHECK CONSTRAINT [FK_WarehouseAddresses_Warehouses_TenantId_WarehouseId]
GO
ALTER TABLE [dbo].[WarehouseLocations]  WITH CHECK ADD  CONSTRAINT [FK_WarehouseLocations_LocationTypes_LocationTypeId] FOREIGN KEY([LocationTypeId])
REFERENCES [dbo].[LocationTypes] ([LocationTypeId])
GO
ALTER TABLE [dbo].[WarehouseLocations] CHECK CONSTRAINT [FK_WarehouseLocations_LocationTypes_LocationTypeId]
GO
ALTER TABLE [dbo].[WarehouseLocations]  WITH CHECK ADD  CONSTRAINT [FK_WarehouseLocations_WarehouseLocations_TenantId_WarehouseId_ParentLocationId] FOREIGN KEY([TenantId], [WarehouseId], [ParentLocationId])
REFERENCES [dbo].[WarehouseLocations] ([TenantId], [WarehouseId], [WarehouseLocationId])
GO
ALTER TABLE [dbo].[WarehouseLocations] CHECK CONSTRAINT [FK_WarehouseLocations_WarehouseLocations_TenantId_WarehouseId_ParentLocationId]
GO
ALTER TABLE [dbo].[WarehouseLocations]  WITH CHECK ADD  CONSTRAINT [FK_WarehouseLocations_Warehouses_TenantId_WarehouseId] FOREIGN KEY([TenantId], [WarehouseId])
REFERENCES [dbo].[Warehouses] ([TenantId], [WarehouseId])
GO
ALTER TABLE [dbo].[WarehouseLocations] CHECK CONSTRAINT [FK_WarehouseLocations_Warehouses_TenantId_WarehouseId]
GO
ALTER TABLE [dbo].[WarehouseLocations]  WITH CHECK ADD  CONSTRAINT [FK_WarehouseLocations_WarehouseZones_WarehouseZoneId] FOREIGN KEY([WarehouseZoneId])
REFERENCES [dbo].[WarehouseZones] ([WarehouseZoneId])
GO
ALTER TABLE [dbo].[WarehouseLocations] CHECK CONSTRAINT [FK_WarehouseLocations_WarehouseZones_WarehouseZoneId]
GO
ALTER TABLE [dbo].[Warehouses]  WITH CHECK ADD  CONSTRAINT [FK_Warehouses_Branches_BranchId] FOREIGN KEY([BranchId])
REFERENCES [dbo].[Branches] ([Id])
GO
ALTER TABLE [dbo].[Warehouses] CHECK CONSTRAINT [FK_Warehouses_Branches_BranchId]
GO
ALTER TABLE [dbo].[Warehouses]  WITH CHECK ADD  CONSTRAINT [FK_Warehouses_Companies_TenantId_CompanyId] FOREIGN KEY([TenantId], [CompanyId])
REFERENCES [dbo].[Companies] ([TenantId], [Id])
GO
ALTER TABLE [dbo].[Warehouses] CHECK CONSTRAINT [FK_Warehouses_Companies_TenantId_CompanyId]
GO
ALTER TABLE [dbo].[WarehouseZones]  WITH CHECK ADD  CONSTRAINT [FK_WarehouseZones_Warehouses_TenantId_WarehouseId] FOREIGN KEY([TenantId], [WarehouseId])
REFERENCES [dbo].[Warehouses] ([TenantId], [WarehouseId])
GO
ALTER TABLE [dbo].[WarehouseZones] CHECK CONSTRAINT [FK_WarehouseZones_Warehouses_TenantId_WarehouseId]
GO
USE [master]
GO
ALTER DATABASE [DomainDB] SET  READ_WRITE 
GO
