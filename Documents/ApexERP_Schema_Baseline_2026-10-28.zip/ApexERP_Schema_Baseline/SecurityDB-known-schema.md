# SecurityDB — Extracted schema summary

Source: SQL Server script pasted by the user on 2026-10-28. This is script-derived and not live-DB verified.

## Tables (10)

- `__EFMigrationsHistory` — migration tracking.
- `Permissions` — unique `Code` index.
- `Roles` — nullable `TenantId`; filtered unique index on (`TenantId`, `Name`) where TenantId is not null.
- `RolePermissions` — links roles to permissions; unique (`RoleId`, `PermissionId`).
- `Users` — nullable `TenantId`; filtered unique indexes on (`TenantId`, `Email`) and (`TenantId`, `Username`) where TenantId is not null.
- `UserRoles` — links users to roles; unique (`UserId`, `RoleId`).
- `UserRoleScopes` — user-role company/branch scopes; filtered unique index on (`UserRoleId`, `CompanyId`, `BranchId`) only when both CompanyId and BranchId are not null.
- `SecurityAuditRecords` — tenant/entity/action audit data.
- `UserSessions` — session lifecycle and revocation fields.
- `RefreshTokens` — hashed refresh-token lifecycle, family, sequence, consumption and revocation fields.

## Explicit foreign keys in the supplied script

- `RefreshTokens.SessionId` → `UserSessions.Id` (cascade delete).
- `RolePermissions.PermissionId` → `Permissions.Id` (cascade delete).
- `RolePermissions.RoleId` → `Roles.Id` (cascade delete).
- `UserRoles.RoleId` → `Roles.Id` (cascade delete).
- `UserRoles.UserId` → `Users.Id` (cascade delete).
- `UserRoleScopes.UserRoleId` → `UserRoles.Id` (cascade delete).
- `UserSessions.UserId` → `Users.Id` (cascade delete).

`TenantId`, `CompanyId` and `BranchId` are not shown as foreign keys in this script. Verify their cross-context references and authorization enforcement in application code; do not add cross-database foreign keys.
