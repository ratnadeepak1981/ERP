USE [master]
GO
/****** Object:  Database [PlatformDB]    Script Date: 10/28/2026 8:09:02 AM ******/
CREATE DATABASE [PlatformDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'PlatformDB', FILENAME = N'C:\Users\UT011647\PlatformDB.mdf' , SIZE = 73728KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'PlatformDB_log', FILENAME = N'C:\Users\UT011647\PlatformDB_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [PlatformDB].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [PlatformDB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [PlatformDB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [PlatformDB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [PlatformDB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [PlatformDB] SET ARITHABORT OFF 
GO
ALTER DATABASE [PlatformDB] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [PlatformDB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [PlatformDB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [PlatformDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [PlatformDB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [PlatformDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [PlatformDB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [PlatformDB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [PlatformDB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [PlatformDB] SET  ENABLE_BROKER 
GO
ALTER DATABASE [PlatformDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [PlatformDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [PlatformDB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [PlatformDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [PlatformDB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [PlatformDB] SET READ_COMMITTED_SNAPSHOT ON 
GO
ALTER DATABASE [PlatformDB] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [PlatformDB] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [PlatformDB] SET  MULTI_USER 
GO
ALTER DATABASE [PlatformDB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [PlatformDB] SET DB_CHAINING OFF 
GO
ALTER DATABASE [PlatformDB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [PlatformDB] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [PlatformDB] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [PlatformDB] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [PlatformDB] SET QUERY_STORE = ON
GO
ALTER DATABASE [PlatformDB] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [PlatformDB]
GO
/****** Object:  Schema [HangFire]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE SCHEMA [HangFire]
GO
/****** Object:  Table [dbo].[__EFMigrationsHistory]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[__EFMigrationsHistory](
	[MigrationId] [nvarchar](150) NOT NULL,
	[ProductVersion] [nvarchar](32) NOT NULL,
 CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY CLUSTERED 
(
	[MigrationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BillingLedgerEntries]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BillingLedgerEntries](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[EntryType] [int] NOT NULL,
	[Direction] [int] NOT NULL,
	[Amount] [decimal](18, 2) NOT NULL,
	[Currency] [nvarchar](3) NOT NULL,
	[PostedAtUtc] [datetime2](7) NOT NULL,
	[SourceDocumentType] [nvarchar](50) NOT NULL,
	[SourceDocumentId] [uniqueidentifier] NOT NULL,
	[ReferenceNumber] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](250) NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_BillingLedgerEntries] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CreditNotes]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CreditNotes](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[SubscriptionInvoiceId] [uniqueidentifier] NOT NULL,
	[CreditNoteNumber] [nvarchar](50) NOT NULL,
	[Amount] [decimal](18, 2) NOT NULL,
	[Currency] [nvarchar](3) NOT NULL,
	[Reason] [nvarchar](250) NOT NULL,
	[IssuedAtUtc] [datetime2](7) NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_CreditNotes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PaymentAllocations]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PaymentAllocations](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[PaymentTransactionId] [uniqueidentifier] NOT NULL,
	[SubscriptionInvoiceId] [uniqueidentifier] NOT NULL,
	[Amount] [decimal](18, 2) NOT NULL,
	[AllocatedAtUtc] [datetime2](7) NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_PaymentAllocations] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PaymentTransactions]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PaymentTransactions](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[PaymentProvider] [nvarchar](50) NOT NULL,
	[ProviderTransactionId] [nvarchar](100) NOT NULL,
	[IdempotencyKey] [nvarchar](100) NOT NULL,
	[PaymentMethod] [int] NOT NULL,
	[Status] [int] NOT NULL,
	[Amount] [decimal](18, 2) NOT NULL,
	[AllocatedAmount] [decimal](18, 2) NOT NULL,
	[RefundedAmount] [decimal](18, 2) NOT NULL,
	[Currency] [nvarchar](3) NOT NULL,
	[ProcessedAtUtc] [datetime2](7) NOT NULL,
	[FailureReason] [nvarchar](500) NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_PaymentTransactions] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PlatformAuditRecords]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PlatformAuditRecords](
	[AuditId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NULL,
	[EntityName] [nvarchar](200) NOT NULL,
	[EntityId] [nvarchar](100) NOT NULL,
	[Action] [nvarchar](50) NOT NULL,
	[UserId] [uniqueidentifier] NULL,
	[Timestamp] [datetime2](7) NOT NULL,
	[OldValues] [nvarchar](max) NULL,
	[NewValues] [nvarchar](max) NULL,
 CONSTRAINT [PK_PlatformAuditRecords] PRIMARY KEY CLUSTERED 
(
	[AuditId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RefundTransactions]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RefundTransactions](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[PaymentTransactionId] [uniqueidentifier] NOT NULL,
	[ProviderRefundId] [nvarchar](100) NOT NULL,
	[Amount] [decimal](18, 2) NOT NULL,
	[Currency] [nvarchar](3) NOT NULL,
	[Reason] [nvarchar](250) NOT NULL,
	[ProcessedAtUtc] [datetime2](7) NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_RefundTransactions] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SubscriptionInvoiceLines]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SubscriptionInvoiceLines](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[SubscriptionInvoiceId] [uniqueidentifier] NOT NULL,
	[Description] [nvarchar](250) NOT NULL,
	[Quantity] [int] NOT NULL,
	[UnitPrice] [decimal](18, 2) NOT NULL,
	[SubTotal] [decimal](18, 2) NOT NULL,
	[TaxRate] [decimal](18, 4) NOT NULL,
	[TaxAmount] [decimal](18, 2) NOT NULL,
	[TotalAmount] [decimal](18, 2) NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SubscriptionInvoiceLines] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SubscriptionInvoices]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SubscriptionInvoices](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[SubscriptionId] [uniqueidentifier] NOT NULL,
	[InvoiceNumber] [nvarchar](50) NOT NULL,
	[Status] [int] NOT NULL,
	[SubTotal] [decimal](18, 2) NOT NULL,
	[TaxAmount] [decimal](18, 2) NOT NULL,
	[TotalAmount] [decimal](18, 2) NOT NULL,
	[PaidAmount] [decimal](18, 2) NOT NULL,
	[CreditedAmount] [decimal](18, 2) NOT NULL,
	[Currency] [nvarchar](3) NOT NULL,
	[IssueDate] [datetime2](7) NOT NULL,
	[DueDate] [datetime2](7) NOT NULL,
	[PaidAt] [datetime2](7) NULL,
	[Notes] [nvarchar](500) NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[BillingCycle] [int] NOT NULL,
	[BillingPeriodEnd] [datetime2](7) NOT NULL,
	[BillingPeriodStart] [datetime2](7) NOT NULL,
	[SequenceNumber] [int] NOT NULL,
 CONSTRAINT [PK_SubscriptionInvoices] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SubscriptionLimits]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SubscriptionLimits](
	[Id] [uniqueidentifier] NOT NULL,
	[SubscriptionPlanId] [uniqueidentifier] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SubscriptionLimits] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SubscriptionParameters]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SubscriptionParameters](
	[Id] [uniqueidentifier] NOT NULL,
	[ParameterKey] [nvarchar](100) NOT NULL,
	[ParameterType] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SubscriptionParameters] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SubscriptionPlanParameters]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SubscriptionPlanParameters](
	[Id] [uniqueidentifier] NOT NULL,
	[SubscriptionLimitId] [uniqueidentifier] NOT NULL,
	[SubscriptionParameterId] [uniqueidentifier] NOT NULL,
	[LimitValue] [decimal](18, 2) NULL,
	[IsUnlimited] [bit] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[Duration] [int] NULL,
 CONSTRAINT [PK_SubscriptionPlanParameters] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SubscriptionPlans]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SubscriptionPlans](
	[Id] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](150) NOT NULL,
	[Code] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](500) NOT NULL,
	[Price] [decimal](18, 2) NOT NULL,
	[BillingCycle] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SubscriptionPlans] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Subscriptions]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Subscriptions](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[SubscriptionName] [nvarchar](100) NOT NULL,
	[SubscriptionType] [nvarchar](50) NOT NULL,
	[StorageMode] [int] NOT NULL,
	[StartDate] [datetime2](7) NOT NULL,
	[EndDate] [datetime2](7) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[SubscriptionPlanId] [uniqueidentifier] NOT NULL,
	[Status] [int] NOT NULL,
	[AutoRenew] [bit] NOT NULL,
	[BillingAnchorDate] [datetime2](7) NOT NULL,
	[BillingCycle] [int] NOT NULL,
	[BillingPlanPriceSnapshot] [decimal](18, 2) NOT NULL,
	[CurrentPeriodStart] [datetime2](7) NOT NULL,
	[CurrentPeriodEnd] [datetime2](7) NOT NULL,
	[LastInvoiceGeneratedAt] [datetime2](7) NULL,
	[NextBillingDate] [datetime2](7) NULL,
 CONSTRAINT [PK_Subscriptions] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SubscriptionUsages]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SubscriptionUsages](
	[Id] [uniqueidentifier] NOT NULL,
	[SubscriptionId] [uniqueidentifier] NOT NULL,
	[SubscriptionPlanParameterId] [uniqueidentifier] NOT NULL,
	[UsageValue] [decimal](18, 2) NOT NULL,
	[PeriodStart] [datetime2](7) NOT NULL,
	[PeriodEnd] [datetime2](7) NOT NULL,
	[LastUpdated] [datetime2](7) NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_SubscriptionUsages] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TenantBillingProfiles]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TenantBillingProfiles](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[BillingEmail] [nvarchar](256) NOT NULL,
	[CompanyName] [nvarchar](200) NOT NULL,
	[TaxId] [nvarchar](50) NULL,
	[Currency] [nvarchar](3) NOT NULL,
	[AddressLine1] [nvarchar](250) NOT NULL,
	[AddressLine2] [nvarchar](250) NULL,
	[City] [nvarchar](100) NOT NULL,
	[StateOrProvince] [nvarchar](100) NULL,
	[PostalCode] [nvarchar](20) NOT NULL,
	[CountryCode] [nvarchar](2) NOT NULL,
	[IsTaxExempt] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_TenantBillingProfiles] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TenantConfigurations]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TenantConfigurations](
	[TenantConfigurationId] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[CompanyEnabled] [bit] NOT NULL,
	[BranchEnabled] [bit] NOT NULL,
	[WarehouseZoneEnabled] [bit] NOT NULL,
	[WarehouseBinEnabled] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
	[ProcurementApprovalMode] [int] NOT NULL,
	[ProcurementApprovalRequired] [bit] NOT NULL,
 CONSTRAINT [PK_TenantConfigurations] PRIMARY KEY CLUSTERED 
(
	[TenantConfigurationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TenantDatabases]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TenantDatabases](
	[Id] [uniqueidentifier] NOT NULL,
	[TenantId] [uniqueidentifier] NOT NULL,
	[DatabaseName] [nvarchar](200) NOT NULL,
	[DatabaseServer] [nvarchar](200) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_TenantDatabases] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Tenants]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Tenants](
	[Id] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](200) NOT NULL,
	[Code] [nvarchar](50) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime2](7) NOT NULL,
	[CreatedBy] [uniqueidentifier] NOT NULL,
	[ModifiedAt] [datetime2](7) NULL,
	[ModifiedBy] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Tenants] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[AggregatedCounter]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[AggregatedCounter](
	[Key] [nvarchar](100) NOT NULL,
	[Value] [bigint] NOT NULL,
	[ExpireAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_CounterAggregated] PRIMARY KEY CLUSTERED 
(
	[Key] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Counter]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Counter](
	[Key] [nvarchar](100) NOT NULL,
	[Value] [int] NOT NULL,
	[ExpireAt] [datetime] NULL,
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_HangFire_Counter] PRIMARY KEY CLUSTERED 
(
	[Key] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Hash]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Hash](
	[Key] [nvarchar](100) NOT NULL,
	[Field] [nvarchar](100) NOT NULL,
	[Value] [nvarchar](max) NULL,
	[ExpireAt] [datetime2](7) NULL,
 CONSTRAINT [PK_HangFire_Hash] PRIMARY KEY CLUSTERED 
(
	[Key] ASC,
	[Field] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Job]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Job](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StateId] [bigint] NULL,
	[StateName] [nvarchar](20) NULL,
	[InvocationData] [nvarchar](max) NOT NULL,
	[Arguments] [nvarchar](max) NOT NULL,
	[CreatedAt] [datetime] NOT NULL,
	[ExpireAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_Job] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[JobParameter]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[JobParameter](
	[JobId] [bigint] NOT NULL,
	[Name] [nvarchar](40) NOT NULL,
	[Value] [nvarchar](max) NULL,
 CONSTRAINT [PK_HangFire_JobParameter] PRIMARY KEY CLUSTERED 
(
	[JobId] ASC,
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[JobQueue]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[JobQueue](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[JobId] [bigint] NOT NULL,
	[Queue] [nvarchar](50) NOT NULL,
	[FetchedAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_JobQueue] PRIMARY KEY CLUSTERED 
(
	[Queue] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[List]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[List](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Key] [nvarchar](100) NOT NULL,
	[Value] [nvarchar](max) NULL,
	[ExpireAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_List] PRIMARY KEY CLUSTERED 
(
	[Key] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Schema]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Schema](
	[Version] [int] NOT NULL,
 CONSTRAINT [PK_HangFire_Schema] PRIMARY KEY CLUSTERED 
(
	[Version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Server]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Server](
	[Id] [nvarchar](200) NOT NULL,
	[Data] [nvarchar](max) NULL,
	[LastHeartbeat] [datetime] NOT NULL,
 CONSTRAINT [PK_HangFire_Server] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Set]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Set](
	[Key] [nvarchar](100) NOT NULL,
	[Score] [float] NOT NULL,
	[Value] [nvarchar](256) NOT NULL,
	[ExpireAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_Set] PRIMARY KEY CLUSTERED 
(
	[Key] ASC,
	[Value] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[State]    Script Date: 10/28/2026 8:09:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[State](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[JobId] [bigint] NOT NULL,
	[Name] [nvarchar](20) NOT NULL,
	[Reason] [nvarchar](100) NULL,
	[CreatedAt] [datetime] NOT NULL,
	[Data] [nvarchar](max) NULL,
 CONSTRAINT [PK_HangFire_State] PRIMARY KEY CLUSTERED 
(
	[JobId] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Index [IX_BillingLedgerEntries_TenantId_PostedAtUtc]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_BillingLedgerEntries_TenantId_PostedAtUtc] ON [dbo].[BillingLedgerEntries]
(
	[TenantId] ASC,
	[PostedAtUtc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_BillingLedgerEntries_TenantId_SourceDocumentType_SourceDocumentId_EntryType_Direction]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_BillingLedgerEntries_TenantId_SourceDocumentType_SourceDocumentId_EntryType_Direction] ON [dbo].[BillingLedgerEntries]
(
	[TenantId] ASC,
	[SourceDocumentType] ASC,
	[SourceDocumentId] ASC,
	[EntryType] ASC,
	[Direction] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_CreditNotes_CreditNoteNumber]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_CreditNotes_CreditNoteNumber] ON [dbo].[CreditNotes]
(
	[CreditNoteNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CreditNotes_SubscriptionInvoiceId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_CreditNotes_SubscriptionInvoiceId] ON [dbo].[CreditNotes]
(
	[SubscriptionInvoiceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CreditNotes_TenantId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_CreditNotes_TenantId] ON [dbo].[CreditNotes]
(
	[TenantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PaymentAllocations_PaymentTransactionId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_PaymentAllocations_PaymentTransactionId] ON [dbo].[PaymentAllocations]
(
	[PaymentTransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PaymentAllocations_SubscriptionInvoiceId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_PaymentAllocations_SubscriptionInvoiceId] ON [dbo].[PaymentAllocations]
(
	[SubscriptionInvoiceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PaymentAllocations_TenantId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_PaymentAllocations_TenantId] ON [dbo].[PaymentAllocations]
(
	[TenantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_PaymentTransactions_PaymentProvider_ProviderTransactionId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_PaymentTransactions_PaymentProvider_ProviderTransactionId] ON [dbo].[PaymentTransactions]
(
	[PaymentProvider] ASC,
	[ProviderTransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_PaymentTransactions_TenantId_PaymentProvider_IdempotencyKey]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_PaymentTransactions_TenantId_PaymentProvider_IdempotencyKey] ON [dbo].[PaymentTransactions]
(
	[TenantId] ASC,
	[PaymentProvider] ASC,
	[IdempotencyKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PaymentTransactions_TenantId_Status]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_PaymentTransactions_TenantId_Status] ON [dbo].[PaymentTransactions]
(
	[TenantId] ASC,
	[Status] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_PlatformAuditRecords_TenantId_EntityName_EntityId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_PlatformAuditRecords_TenantId_EntityName_EntityId] ON [dbo].[PlatformAuditRecords]
(
	[TenantId] ASC,
	[EntityName] ASC,
	[EntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PlatformAuditRecords_Timestamp]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_PlatformAuditRecords_Timestamp] ON [dbo].[PlatformAuditRecords]
(
	[Timestamp] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_RefundTransactions_PaymentTransactionId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_RefundTransactions_PaymentTransactionId] ON [dbo].[RefundTransactions]
(
	[PaymentTransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_RefundTransactions_ProviderRefundId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_RefundTransactions_ProviderRefundId] ON [dbo].[RefundTransactions]
(
	[ProviderRefundId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_RefundTransactions_TenantId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_RefundTransactions_TenantId] ON [dbo].[RefundTransactions]
(
	[TenantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionInvoiceLines_SubscriptionInvoiceId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_SubscriptionInvoiceLines_SubscriptionInvoiceId] ON [dbo].[SubscriptionInvoiceLines]
(
	[SubscriptionInvoiceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionInvoiceLines_TenantId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_SubscriptionInvoiceLines_TenantId] ON [dbo].[SubscriptionInvoiceLines]
(
	[TenantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_SubscriptionInvoices_InvoiceNumber]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SubscriptionInvoices_InvoiceNumber] ON [dbo].[SubscriptionInvoices]
(
	[InvoiceNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionInvoices_SubscriptionId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_SubscriptionInvoices_SubscriptionId] ON [dbo].[SubscriptionInvoices]
(
	[SubscriptionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionInvoices_SubscriptionId_BillingPeriodStart_BillingPeriodEnd]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SubscriptionInvoices_SubscriptionId_BillingPeriodStart_BillingPeriodEnd] ON [dbo].[SubscriptionInvoices]
(
	[SubscriptionId] ASC,
	[BillingPeriodStart] ASC,
	[BillingPeriodEnd] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionInvoices_TenantId_Status]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_SubscriptionInvoices_TenantId_Status] ON [dbo].[SubscriptionInvoices]
(
	[TenantId] ASC,
	[Status] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionLimits_SubscriptionPlanId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SubscriptionLimits_SubscriptionPlanId] ON [dbo].[SubscriptionLimits]
(
	[SubscriptionPlanId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_SubscriptionParameters_ParameterKey]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SubscriptionParameters_ParameterKey] ON [dbo].[SubscriptionParameters]
(
	[ParameterKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionPlanParameters_SubscriptionLimitId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_SubscriptionPlanParameters_SubscriptionLimitId] ON [dbo].[SubscriptionPlanParameters]
(
	[SubscriptionLimitId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionPlanParameters_SubscriptionLimitId_SubscriptionParameterId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SubscriptionPlanParameters_SubscriptionLimitId_SubscriptionParameterId] ON [dbo].[SubscriptionPlanParameters]
(
	[SubscriptionLimitId] ASC,
	[SubscriptionParameterId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionPlanParameters_SubscriptionParameterId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_SubscriptionPlanParameters_SubscriptionParameterId] ON [dbo].[SubscriptionPlanParameters]
(
	[SubscriptionParameterId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_SubscriptionPlans_Code]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SubscriptionPlans_Code] ON [dbo].[SubscriptionPlans]
(
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Subscriptions_SubscriptionPlanId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_Subscriptions_SubscriptionPlanId] ON [dbo].[Subscriptions]
(
	[SubscriptionPlanId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Subscriptions_TenantId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Subscriptions_TenantId] ON [dbo].[Subscriptions]
(
	[TenantId] ASC
)
WHERE ([IsActive]=(1))
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionUsages_SubscriptionId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_SubscriptionUsages_SubscriptionId] ON [dbo].[SubscriptionUsages]
(
	[SubscriptionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionUsages_SubscriptionId_SubscriptionPlanParameterId_PeriodStart_PeriodEnd]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_SubscriptionUsages_SubscriptionId_SubscriptionPlanParameterId_PeriodStart_PeriodEnd] ON [dbo].[SubscriptionUsages]
(
	[SubscriptionId] ASC,
	[SubscriptionPlanParameterId] ASC,
	[PeriodStart] ASC,
	[PeriodEnd] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_SubscriptionUsages_SubscriptionPlanParameterId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_SubscriptionUsages_SubscriptionPlanParameterId] ON [dbo].[SubscriptionUsages]
(
	[SubscriptionPlanParameterId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_TenantBillingProfiles_TenantId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_TenantBillingProfiles_TenantId] ON [dbo].[TenantBillingProfiles]
(
	[TenantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_TenantConfigurations_TenantId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_TenantConfigurations_TenantId] ON [dbo].[TenantConfigurations]
(
	[TenantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_TenantDatabases_TenantId]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_TenantDatabases_TenantId] ON [dbo].[TenantDatabases]
(
	[TenantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Tenants_Code]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Tenants_Code] ON [dbo].[Tenants]
(
	[Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Tenants_Name]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_Tenants_Name] ON [dbo].[Tenants]
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_HangFire_AggregatedCounter_ExpireAt]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_HangFire_AggregatedCounter_ExpireAt] ON [HangFire].[AggregatedCounter]
(
	[ExpireAt] ASC
)
WHERE ([ExpireAt] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_HangFire_Hash_ExpireAt]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_HangFire_Hash_ExpireAt] ON [HangFire].[Hash]
(
	[ExpireAt] ASC
)
WHERE ([ExpireAt] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_HangFire_Job_ExpireAt]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_HangFire_Job_ExpireAt] ON [HangFire].[Job]
(
	[ExpireAt] ASC
)
INCLUDE([StateName]) 
WHERE ([ExpireAt] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_HangFire_Job_StateName]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_HangFire_Job_StateName] ON [HangFire].[Job]
(
	[StateName] ASC
)
WHERE ([StateName] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_HangFire_List_ExpireAt]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_HangFire_List_ExpireAt] ON [HangFire].[List]
(
	[ExpireAt] ASC
)
WHERE ([ExpireAt] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_HangFire_Server_LastHeartbeat]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_HangFire_Server_LastHeartbeat] ON [HangFire].[Server]
(
	[LastHeartbeat] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_HangFire_Set_ExpireAt]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_HangFire_Set_ExpireAt] ON [HangFire].[Set]
(
	[ExpireAt] ASC
)
WHERE ([ExpireAt] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_HangFire_Set_Score]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_HangFire_Set_Score] ON [HangFire].[Set]
(
	[Key] ASC,
	[Score] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_HangFire_State_CreatedAt]    Script Date: 10/28/2026 8:09:03 AM ******/
CREATE NONCLUSTERED INDEX [IX_HangFire_State_CreatedAt] ON [HangFire].[State]
(
	[CreatedAt] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[SubscriptionInvoices] ADD  DEFAULT ((0)) FOR [BillingCycle]
GO
ALTER TABLE [dbo].[SubscriptionInvoices] ADD  DEFAULT ('0001-01-01T00:00:00.0000000') FOR [BillingPeriodEnd]
GO
ALTER TABLE [dbo].[SubscriptionInvoices] ADD  DEFAULT ('0001-01-01T00:00:00.0000000') FOR [BillingPeriodStart]
GO
ALTER TABLE [dbo].[SubscriptionInvoices] ADD  DEFAULT ((0)) FOR [SequenceNumber]
GO
ALTER TABLE [dbo].[Subscriptions] ADD  DEFAULT ('11111111-1111-1111-1111-111111111111') FOR [SubscriptionPlanId]
GO
ALTER TABLE [dbo].[TenantConfigurations] ADD  DEFAULT ((1)) FOR [ProcurementApprovalMode]
GO
ALTER TABLE [dbo].[TenantConfigurations] ADD  DEFAULT (CONVERT([bit],(1))) FOR [ProcurementApprovalRequired]
GO
ALTER TABLE [dbo].[BillingLedgerEntries]  WITH CHECK ADD  CONSTRAINT [FK_BillingLedgerEntries_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
GO
ALTER TABLE [dbo].[BillingLedgerEntries] CHECK CONSTRAINT [FK_BillingLedgerEntries_Tenants_TenantId]
GO
ALTER TABLE [dbo].[CreditNotes]  WITH CHECK ADD  CONSTRAINT [FK_CreditNotes_SubscriptionInvoices_SubscriptionInvoiceId] FOREIGN KEY([SubscriptionInvoiceId])
REFERENCES [dbo].[SubscriptionInvoices] ([Id])
GO
ALTER TABLE [dbo].[CreditNotes] CHECK CONSTRAINT [FK_CreditNotes_SubscriptionInvoices_SubscriptionInvoiceId]
GO
ALTER TABLE [dbo].[CreditNotes]  WITH CHECK ADD  CONSTRAINT [FK_CreditNotes_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
GO
ALTER TABLE [dbo].[CreditNotes] CHECK CONSTRAINT [FK_CreditNotes_Tenants_TenantId]
GO
ALTER TABLE [dbo].[PaymentAllocations]  WITH CHECK ADD  CONSTRAINT [FK_PaymentAllocations_PaymentTransactions_PaymentTransactionId] FOREIGN KEY([PaymentTransactionId])
REFERENCES [dbo].[PaymentTransactions] ([Id])
GO
ALTER TABLE [dbo].[PaymentAllocations] CHECK CONSTRAINT [FK_PaymentAllocations_PaymentTransactions_PaymentTransactionId]
GO
ALTER TABLE [dbo].[PaymentAllocations]  WITH CHECK ADD  CONSTRAINT [FK_PaymentAllocations_SubscriptionInvoices_SubscriptionInvoiceId] FOREIGN KEY([SubscriptionInvoiceId])
REFERENCES [dbo].[SubscriptionInvoices] ([Id])
GO
ALTER TABLE [dbo].[PaymentAllocations] CHECK CONSTRAINT [FK_PaymentAllocations_SubscriptionInvoices_SubscriptionInvoiceId]
GO
ALTER TABLE [dbo].[PaymentAllocations]  WITH CHECK ADD  CONSTRAINT [FK_PaymentAllocations_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
GO
ALTER TABLE [dbo].[PaymentAllocations] CHECK CONSTRAINT [FK_PaymentAllocations_Tenants_TenantId]
GO
ALTER TABLE [dbo].[PaymentTransactions]  WITH CHECK ADD  CONSTRAINT [FK_PaymentTransactions_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
GO
ALTER TABLE [dbo].[PaymentTransactions] CHECK CONSTRAINT [FK_PaymentTransactions_Tenants_TenantId]
GO
ALTER TABLE [dbo].[RefundTransactions]  WITH CHECK ADD  CONSTRAINT [FK_RefundTransactions_PaymentTransactions_PaymentTransactionId] FOREIGN KEY([PaymentTransactionId])
REFERENCES [dbo].[PaymentTransactions] ([Id])
GO
ALTER TABLE [dbo].[RefundTransactions] CHECK CONSTRAINT [FK_RefundTransactions_PaymentTransactions_PaymentTransactionId]
GO
ALTER TABLE [dbo].[RefundTransactions]  WITH CHECK ADD  CONSTRAINT [FK_RefundTransactions_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
GO
ALTER TABLE [dbo].[RefundTransactions] CHECK CONSTRAINT [FK_RefundTransactions_Tenants_TenantId]
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines]  WITH CHECK ADD  CONSTRAINT [FK_SubscriptionInvoiceLines_SubscriptionInvoices_SubscriptionInvoiceId] FOREIGN KEY([SubscriptionInvoiceId])
REFERENCES [dbo].[SubscriptionInvoices] ([Id])
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines] CHECK CONSTRAINT [FK_SubscriptionInvoiceLines_SubscriptionInvoices_SubscriptionInvoiceId]
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines]  WITH CHECK ADD  CONSTRAINT [FK_SubscriptionInvoiceLines_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines] CHECK CONSTRAINT [FK_SubscriptionInvoiceLines_Tenants_TenantId]
GO
ALTER TABLE [dbo].[SubscriptionInvoices]  WITH CHECK ADD  CONSTRAINT [FK_SubscriptionInvoices_Subscriptions_SubscriptionId] FOREIGN KEY([SubscriptionId])
REFERENCES [dbo].[Subscriptions] ([Id])
GO
ALTER TABLE [dbo].[SubscriptionInvoices] CHECK CONSTRAINT [FK_SubscriptionInvoices_Subscriptions_SubscriptionId]
GO
ALTER TABLE [dbo].[SubscriptionInvoices]  WITH CHECK ADD  CONSTRAINT [FK_SubscriptionInvoices_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
GO
ALTER TABLE [dbo].[SubscriptionInvoices] CHECK CONSTRAINT [FK_SubscriptionInvoices_Tenants_TenantId]
GO
ALTER TABLE [dbo].[SubscriptionLimits]  WITH CHECK ADD  CONSTRAINT [FK_SubscriptionLimits_SubscriptionPlans_SubscriptionPlanId] FOREIGN KEY([SubscriptionPlanId])
REFERENCES [dbo].[SubscriptionPlans] ([Id])
GO
ALTER TABLE [dbo].[SubscriptionLimits] CHECK CONSTRAINT [FK_SubscriptionLimits_SubscriptionPlans_SubscriptionPlanId]
GO
ALTER TABLE [dbo].[SubscriptionPlanParameters]  WITH CHECK ADD  CONSTRAINT [FK_SubscriptionPlanParameters_SubscriptionLimits_SubscriptionLimitId] FOREIGN KEY([SubscriptionLimitId])
REFERENCES [dbo].[SubscriptionLimits] ([Id])
GO
ALTER TABLE [dbo].[SubscriptionPlanParameters] CHECK CONSTRAINT [FK_SubscriptionPlanParameters_SubscriptionLimits_SubscriptionLimitId]
GO
ALTER TABLE [dbo].[SubscriptionPlanParameters]  WITH CHECK ADD  CONSTRAINT [FK_SubscriptionPlanParameters_SubscriptionParameters_SubscriptionParameterId] FOREIGN KEY([SubscriptionParameterId])
REFERENCES [dbo].[SubscriptionParameters] ([Id])
GO
ALTER TABLE [dbo].[SubscriptionPlanParameters] CHECK CONSTRAINT [FK_SubscriptionPlanParameters_SubscriptionParameters_SubscriptionParameterId]
GO
ALTER TABLE [dbo].[Subscriptions]  WITH CHECK ADD  CONSTRAINT [FK_Subscriptions_SubscriptionPlans_SubscriptionPlanId] FOREIGN KEY([SubscriptionPlanId])
REFERENCES [dbo].[SubscriptionPlans] ([Id])
GO
ALTER TABLE [dbo].[Subscriptions] CHECK CONSTRAINT [FK_Subscriptions_SubscriptionPlans_SubscriptionPlanId]
GO
ALTER TABLE [dbo].[Subscriptions]  WITH CHECK ADD  CONSTRAINT [FK_Subscriptions_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
GO
ALTER TABLE [dbo].[Subscriptions] CHECK CONSTRAINT [FK_Subscriptions_Tenants_TenantId]
GO
ALTER TABLE [dbo].[SubscriptionUsages]  WITH CHECK ADD  CONSTRAINT [FK_SubscriptionUsages_SubscriptionPlanParameters_SubscriptionPlanParameterId] FOREIGN KEY([SubscriptionPlanParameterId])
REFERENCES [dbo].[SubscriptionPlanParameters] ([Id])
GO
ALTER TABLE [dbo].[SubscriptionUsages] CHECK CONSTRAINT [FK_SubscriptionUsages_SubscriptionPlanParameters_SubscriptionPlanParameterId]
GO
ALTER TABLE [dbo].[SubscriptionUsages]  WITH CHECK ADD  CONSTRAINT [FK_SubscriptionUsages_Subscriptions_SubscriptionId] FOREIGN KEY([SubscriptionId])
REFERENCES [dbo].[Subscriptions] ([Id])
GO
ALTER TABLE [dbo].[SubscriptionUsages] CHECK CONSTRAINT [FK_SubscriptionUsages_Subscriptions_SubscriptionId]
GO
ALTER TABLE [dbo].[TenantBillingProfiles]  WITH CHECK ADD  CONSTRAINT [FK_TenantBillingProfiles_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
GO
ALTER TABLE [dbo].[TenantBillingProfiles] CHECK CONSTRAINT [FK_TenantBillingProfiles_Tenants_TenantId]
GO
ALTER TABLE [dbo].[TenantConfigurations]  WITH CHECK ADD  CONSTRAINT [FK_TenantConfigurations_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[TenantConfigurations] CHECK CONSTRAINT [FK_TenantConfigurations_Tenants_TenantId]
GO
ALTER TABLE [dbo].[TenantDatabases]  WITH CHECK ADD  CONSTRAINT [FK_TenantDatabases_Tenants_TenantId] FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[TenantDatabases] CHECK CONSTRAINT [FK_TenantDatabases_Tenants_TenantId]
GO
ALTER TABLE [HangFire].[JobParameter]  WITH CHECK ADD  CONSTRAINT [FK_HangFire_JobParameter_Job] FOREIGN KEY([JobId])
REFERENCES [HangFire].[Job] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [HangFire].[JobParameter] CHECK CONSTRAINT [FK_HangFire_JobParameter_Job]
GO
ALTER TABLE [HangFire].[State]  WITH CHECK ADD  CONSTRAINT [FK_HangFire_State_Job] FOREIGN KEY([JobId])
REFERENCES [HangFire].[Job] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [HangFire].[State] CHECK CONSTRAINT [FK_HangFire_State_Job]
GO
ALTER TABLE [dbo].[BillingLedgerEntries]  WITH CHECK ADD  CONSTRAINT [CK_BillingLedgerEntries_Amount_Positive] CHECK  (([Amount]>(0)))
GO
ALTER TABLE [dbo].[BillingLedgerEntries] CHECK CONSTRAINT [CK_BillingLedgerEntries_Amount_Positive]
GO
ALTER TABLE [dbo].[CreditNotes]  WITH CHECK ADD  CONSTRAINT [CK_CreditNotes_Amount_Positive] CHECK  (([Amount]>(0)))
GO
ALTER TABLE [dbo].[CreditNotes] CHECK CONSTRAINT [CK_CreditNotes_Amount_Positive]
GO
ALTER TABLE [dbo].[PaymentAllocations]  WITH CHECK ADD  CONSTRAINT [CK_PaymentAllocations_Amount_Positive] CHECK  (([Amount]>(0)))
GO
ALTER TABLE [dbo].[PaymentAllocations] CHECK CONSTRAINT [CK_PaymentAllocations_Amount_Positive]
GO
ALTER TABLE [dbo].[PaymentTransactions]  WITH CHECK ADD  CONSTRAINT [CK_PaymentTransactions_AllocatedAmount_NonNegative] CHECK  (([AllocatedAmount]>=(0)))
GO
ALTER TABLE [dbo].[PaymentTransactions] CHECK CONSTRAINT [CK_PaymentTransactions_AllocatedAmount_NonNegative]
GO
ALTER TABLE [dbo].[PaymentTransactions]  WITH CHECK ADD  CONSTRAINT [CK_PaymentTransactions_Amount_Positive] CHECK  (([Amount]>(0)))
GO
ALTER TABLE [dbo].[PaymentTransactions] CHECK CONSTRAINT [CK_PaymentTransactions_Amount_Positive]
GO
ALTER TABLE [dbo].[PaymentTransactions]  WITH CHECK ADD  CONSTRAINT [CK_PaymentTransactions_RefundedAmount_NonNegative] CHECK  (([RefundedAmount]>=(0)))
GO
ALTER TABLE [dbo].[PaymentTransactions] CHECK CONSTRAINT [CK_PaymentTransactions_RefundedAmount_NonNegative]
GO
ALTER TABLE [dbo].[RefundTransactions]  WITH CHECK ADD  CONSTRAINT [CK_RefundTransactions_Amount_Positive] CHECK  (([Amount]>(0)))
GO
ALTER TABLE [dbo].[RefundTransactions] CHECK CONSTRAINT [CK_RefundTransactions_Amount_Positive]
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoiceLines_Quantity_Positive] CHECK  (([Quantity]>(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines] CHECK CONSTRAINT [CK_SubscriptionInvoiceLines_Quantity_Positive]
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoiceLines_SubTotal_NonNegative] CHECK  (([SubTotal]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines] CHECK CONSTRAINT [CK_SubscriptionInvoiceLines_SubTotal_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoiceLines_TaxAmount_NonNegative] CHECK  (([TaxAmount]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines] CHECK CONSTRAINT [CK_SubscriptionInvoiceLines_TaxAmount_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoiceLines_TaxRate_NonNegative] CHECK  (([TaxRate]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines] CHECK CONSTRAINT [CK_SubscriptionInvoiceLines_TaxRate_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoiceLines_TotalAmount_NonNegative] CHECK  (([TotalAmount]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines] CHECK CONSTRAINT [CK_SubscriptionInvoiceLines_TotalAmount_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoiceLines_UnitPrice_NonNegative] CHECK  (([UnitPrice]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoiceLines] CHECK CONSTRAINT [CK_SubscriptionInvoiceLines_UnitPrice_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionInvoices]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoices_CreditedAmount_NonNegative] CHECK  (([CreditedAmount]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoices] CHECK CONSTRAINT [CK_SubscriptionInvoices_CreditedAmount_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionInvoices]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoices_PaidAmount_NonNegative] CHECK  (([PaidAmount]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoices] CHECK CONSTRAINT [CK_SubscriptionInvoices_PaidAmount_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionInvoices]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoices_SubTotal_NonNegative] CHECK  (([SubTotal]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoices] CHECK CONSTRAINT [CK_SubscriptionInvoices_SubTotal_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionInvoices]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoices_TaxAmount_NonNegative] CHECK  (([TaxAmount]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoices] CHECK CONSTRAINT [CK_SubscriptionInvoices_TaxAmount_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionInvoices]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionInvoices_TotalAmount_NonNegative] CHECK  (([TotalAmount]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionInvoices] CHECK CONSTRAINT [CK_SubscriptionInvoices_TotalAmount_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionPlanParameters]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionPlanParameters_LimitValue_NonNegative] CHECK  (([LimitValue] IS NULL OR [LimitValue]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionPlanParameters] CHECK CONSTRAINT [CK_SubscriptionPlanParameters_LimitValue_NonNegative]
GO
ALTER TABLE [dbo].[SubscriptionPlanParameters]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionPlanParameters_Unlimited_LimitValue] CHECK  (([IsUnlimited]=(1) AND [LimitValue] IS NULL OR [IsUnlimited]=(0) AND [LimitValue] IS NOT NULL))
GO
ALTER TABLE [dbo].[SubscriptionPlanParameters] CHECK CONSTRAINT [CK_SubscriptionPlanParameters_Unlimited_LimitValue]
GO
ALTER TABLE [dbo].[SubscriptionPlans]  WITH CHECK ADD  CONSTRAINT [CK_SubscriptionPlans_Price_NonNegative] CHECK  (([Price]>=(0)))
GO
ALTER TABLE [dbo].[SubscriptionPlans] CHECK CONSTRAINT [CK_SubscriptionPlans_Price_NonNegative]
GO
USE [master]
GO
ALTER DATABASE [PlatformDB] SET  READ_WRITE 
GO
