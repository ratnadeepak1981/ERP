# ApexERP Database Schema Baseline

**Prepared:** 2026-10-28  
**Purpose:** Read-only schema baseline for Round 2 Master Data, Product Master and seed-data design.  
**Scope:** Extracted DomainDB and PlatformDB SQL Server scripts plus the SecurityDB schema pasted in the conversation.  
**Verification status:** Script-derived, not independently verified against a live SQL Server connection.

## Inventory

| Database | Table count in supplied script | Source |
|---|---:|---|
| DomainDB | 53 | Uploaded SQL script |
| PlatformDB | 30 | Uploaded SQL script (includes Hangfire tables) |
| SecurityDB | 10 | User-provided script text |

The DomainDB and PlatformDB scripts include database creation and local file paths. Treat these as schema-export artifacts, not deployment scripts to execute. No SQL was executed during this documentation step.

## Files

- `table-column-catalog.csv` — parsed columns, data types, nullability and primary-key columns. Defaults are included where parsed from the supplied scripts; review against EF Core configuration.
- `foreign-key-relationships.csv` — explicit foreign keys found in scripts, including delete behavior where identifiable. Application-level relationships without database FKs are not represented.
- `index-catalog.csv` — indexes and uniqueness/filter metadata parsed from scripts.
- `DomainDB-source-extract.sql` and `PlatformDB-source-extract.sql` — normalized UTF-8 copies of the uploaded scripts for audit reference.
- `SecurityDB-known-schema.md` — concise source-based summary of SecurityDB tables and relationships from the pasted script.

## Important limitations

1. This is a script-derived baseline, not proof that the live databases match the scripts.
2. EF Core entities, Fluent API configuration, migrations and `__EFMigrationsHistory` still need comparison.
3. SecurityDB table/column details were transcribed from the pasted script; the original file was not uploaded as an attachment.
4. Table/column parser output should be reviewed for unusual computed columns, defaults, filtered indexes and SQL syntax edge cases.
5. Do not infer that a capability is missing only because no obvious column was found. Check entities, related tables, owned types and application code first.
6. The schema may contain names or machine-specific file paths; source extracts are retained for traceability and should not be published publicly without review.

## Next workflow

1. Compare this baseline with EF Core entity/configuration files and migration snapshots.
2. Record schema drift and unresolved differences.
3. Map existing masters to the five initial tenant profiles: Retail; Wholesale & Distribution; Import & Export; Hardware & Building Materials; Service & Maintenance.
4. Preserve existing provisioning and seeding architecture; defer multi-company tenant testing.
5. Approve any required schema changes before implementation.

## Maintenance rule

Update this catalogue and the related relationship/fit-gap documentation in the same approved task whenever database-related code or migrations change. Never change the database merely to match documentation.
